# 基于 ZYNQ 的睡眠监测系统——比赛提交源码

整理日期：2026-11-02。
整理依据：用户提供的上传页面截图要求“上传全部代码，RAR 格式，200MB 以内”，以及用户已明确的“只交对应板上程序源码”范围。
版本：score_review_oled，通信 ABI 0x10004，对应最新《实物与软件截图版》报告中的实时监测、历史记录和实验参考分页。

## 内容与入口

| 路径 | 内容 |
|---|---|
| sleep_monitor/bringup/score_review_oled/rtl/ | 当前 FPGA 逻辑；standalone_core.v 是核心顶层 |
| sleep_monitor/bringup/motion_buzzer_oled/rtl/ | 最终工程实际使用的采样、心率、声音事件、体动和蜂鸣器基础模块 |
| sleep_monitor/bringup/motion_buzzer_oled/constraints/shared.xdc | 引脚和时钟约束 |
| sleep_monitor/rtl/uart.v | 工程依赖的 UART 模块 |
| sleep_monitor/bringup/score_review_oled/create_project.tcl | 自动创建 Vivado 工程和 ZYNQ Block Design |
| sleep_monitor/bringup/score_review_oled/reference/ps_config.tcl | ZYNQ PS 配置 |
| sleep_monitor/bringup/score_review_oled/board/ | ARM 实际运行的 Python 源码、服务配置和规则参数 |
| sleep_monitor/bringup/score_review_oled/WIRING.md | 配套接线说明 |

ARM 服务入口是 start_research.py，由 load_overlay.py 校验和加载 FPGA，再运行 run_research.py。
audio_ring.py 读取 FPGA 音频缓存并提交结果；model_runtime.py 调用固定模型；review_tracker.py 和 base_review_tracker.py 实现提醒规则；history_store.py 保存记录；reference_score.py 计算实验参考分。

## FPGA 源码重建

环境：Vivado 2023.1，器件 xc7z020clg400-2。请完整解压到短英文路径，例如 C:/sm_source，保留全部相对目录。

在 Vivado Tcl Console 执行以下命令，路径按实际位置替换：

    source C:/sm_source/sleep_monitor/bringup/score_review_oled/create_project.tcl

工程生成后点击 Generate Bitstream。脚本自动生成顶层 s_wrapper；产物为该目录下 build/ps/standalone.runs/impl_1/s_wrapper.bit。
比赛上传本 RAR 源码包。实机配置 FPGA 时才在 Program Device 中选择 BIT 文件；ARM 程序则在 TF 卡 Linux 中运行。

## ARM 运行环境与第三方依赖

板上环境为 PYNQ/Linux、ARMv7 Cortex-A9、Python 3.8、NumPy、PYNQ/XRT。服务配置使用 /usr/local/share/pynq-venv/bin/python3，应用路径为 /home/xilinx/sleep_monitor_20261029/score_review_oled。
现有历史数据库由程序在旧 history_review_oled/history 目录中共享保存；该路径用于保留已有监测记录，不表示本包还需要旧版 ARM 源码。

源码包未附带模型权重、预编译运行库、BIT/HWH/XSA、运行时校验文件、录音、日志、历史数据库、仿真测试、电脑调试工具或旧版工程。原始程序文件保持原内容。
实际部署仍需配套的完整板上运行文件：固定 YAMNet 模型、vendor_arm_cortex_a9、overlay、arm_probe.json、bundle_manifest.json、golden 和 licenses。verify_bundle.py 等启动检查需要这套文件，因此本源码包不能作为完整 TF 卡运行镜像直接部署。
对应完整板上应用为原工程 dist/score_board_20261029.zip，可供实际部署时使用；它没有混入本次源码提交包。
第三方模型和运行库来源、许可证及固定模型哈希见 board/THIRD_PARTY_NOTICES.md 和 LICENSE-APACHE-2.0.txt；模型为预训练 YAMNet，项目没有重新训练权重。

## 文件与版本校验

文件清单见 文件清单.txt，逐文件 SHA-256 见 FILE_SHA256.json，SOURCE_VERSION.json 标明版本和源码原始路径。
本次核对了全部 21 个硬件构建输入的哈希，以及 10 个 ARM 程序与已归档部署包的一致性。功能测试结果保存在提交 RAR 外的整理校验记录中。
本次只整理和验证源码，没有下载硬件、修改 TF 卡、启用服务或重新宣称实板通过。

实验参考分及音频提醒属于项目演示，不是医学健康诊断。最终部署记录尚未确认本参考分页版本的冷启动验收；保留此限制，不沿用旧版本的冷启动结论。
