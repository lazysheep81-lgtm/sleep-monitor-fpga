`timescale 1ns/1ps
// Active-high buzzer module. One 100 ms test per debounced PL_KEY0 press.
// Power-on held key cannot trigger. No automatic health or sound alarm.
module manual_buzzer #(parameter integer CLK_HZ=50_000_000)(
    input wire clk,rst_n,key_n,output wire beep
);
    (* ASYNC_REG="TRUE" *) reg [1:0] key_sync;
    reg stable,armed;
    reg [31:0] debounce_count,pulse_left;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin key_sync<=0;stable<=0;armed<=0;debounce_count<=0;pulse_left<=0;end
        else begin
            key_sync<={key_sync[0],key_n};
            if(pulse_left!=0) pulse_left<=pulse_left-1'b1;
            if(key_sync[1]==stable) debounce_count<=0;
            else if(debounce_count>=CLK_HZ/50-1) begin
                stable<=key_sync[1];debounce_count<=0;
                if(key_sync[1]) armed<=1;
                else if(armed) begin pulse_left<=CLK_HZ/10;armed<=0;end
            end else debounce_count<=debounce_count+1'b1;
        end
    end
    assign beep=rst_n && pulse_left!=0;
endmodule
