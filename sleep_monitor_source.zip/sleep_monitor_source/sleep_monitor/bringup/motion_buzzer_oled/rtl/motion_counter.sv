`timescale 1ns/1ps
// Engineering movement counter, not sleep-stage or health classification.
module motion_counter #(parameter integer ON_DELTA=2048,OFF_DELTA=512)(
    input wire clk,rst_n,live,sample_valid,
    input wire signed [15:0] ax,ay,az,
    output reg active,output reg [23:0] count
);
    reg previous_valid;
    reg signed [15:0] px,py,pz;
    reg [2:0] high_run,low_run;
    function [16:0] distance(input signed [15:0] a,b);
        reg signed [16:0] d;
        begin d={a[15],a}-{b[15],b};distance=d<0?-d:d;end
    endfunction
    wire [18:0] delta={2'b0,distance(ax,px)}+{2'b0,distance(ay,py)}+{2'b0,distance(az,pz)};
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin previous_valid<=0;px<=0;py<=0;pz<=0;high_run<=0;low_run<=0;active<=0;count<=0;end
        else if(!live) begin previous_valid<=0;high_run<=0;low_run<=0;active<=0;end
        else if(sample_valid) begin
            px<=ax;py<=ay;pz<=az;previous_valid<=1;
            if(previous_valid) begin
                if(!active) begin
                    low_run<=0;
                    if(delta>=ON_DELTA) begin
                        if(high_run==2) begin
                            active<=1;high_run<=0;
                            if(count!=24'hffffff) count<=count+1'b1;
                        end else high_run<=high_run+1'b1;
                    end else high_run<=0;
                end else begin
                    high_run<=0;
                    if(delta<=OFF_DELTA) begin
                        if(low_run==4) begin active<=0;low_run<=0;end
                        else low_run<=low_run+1'b1;
                    end else low_run<=0;
                end
            end
        end
    end
endmodule
