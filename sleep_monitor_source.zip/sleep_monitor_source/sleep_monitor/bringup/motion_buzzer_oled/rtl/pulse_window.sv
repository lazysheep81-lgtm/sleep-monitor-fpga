`timescale 1ns/1ps
// Integer 8-second, two-channel estimator. No synthetic data or health labels.
// Analysis bandwidth 35..200 bpm; these are NOT normal/abnormal thresholds.
module pulse_window #(parameter integer CLK_HZ=50_000_000)(
    input wire clk,rst_n,enable,tick,
    input wire [17:0] red,ir,input wire [31:0] sequence_number,
    output reg [7:0] bpm,output reg valid,
    output reg analysis_done,output reg [11:0] candidate10,
    output wire busy
);
    localparam IDLE=0,COPY=1,SM_INIT=2,SM_SUM=3,SM_STORE=4,
        BASE_INIT=5,BASE_SUM=6,BASE_STORE=7,DRIFT=8,
        FIL_INIT=9,FIL_SUM=10,FIL_STORE=11,ENERGY_INIT=12,ENERGY_SUM=13,
        ENERGY_PRODUCT=14,CROSS_CHECK=15,AC_INIT=16,AC_SUM=17,
        DIV_R=18,WAIT_R=19,DIV_I=20,WAIT_I=21,
        FIND_BEST=22,FIND_FIRST=23,PERIOD_CHECK=24,
        PEAK_INIT=25,PEAK_TEST=26,PEAK_RANGE=27,PEAK_STORE=28,
        SORT_INIT=29,SORT=30,MEDIAN=31,GOOD=32,GOOD_CHECK=33,
        CV_PRODUCT=34,CV_CHECK=35,DIV_PEAK=36,WAIT_PEAK=37,
        DIV_AC=38,WAIT_AC=39,FINISH=40,REJECT=41;
    reg [5:0] state;
    assign busy=(state!=IDLE);
    (* ram_style="distributed" *) reg [17:0] ring_r[0:799],ring_i[0:799];
    (* ram_style="distributed" *) reg [17:0] raw_r[0:799],raw_i[0:799];
    (* ram_style="distributed" *) reg [17:0] sm_r[0:799],sm_i[0:799];
    (* ram_style="distributed" *) reg signed [18:0] sig_r[0:719],sig_i[0:719];
    (* ram_style="distributed" *) reg [10:0] score_r[0:141],score_i[0:141];
    reg [9:0] rr[0:39],good_rr[0:39];
    reg [9:0] pointer,filled,copy_pointer,index;
    reg [6:0] hop,offset;
    reg [31:0] expected_sequence,age;
    reg have_sequence;
    wire contact=red>=15000 && ir>=20000 && red<=262139 && ir<=262139;
    wire discontinuity=have_sequence && sequence_number!=expected_sequence;
    reg [31:0] sum_r,sum_i,dc_r,dc_i;
    reg [17:0] min_r,max_r,min_i,max_i;
    reg [47:0] energy_r,energy_i;
    reg signed [47:0] cross_sum;
    reg [95:0] cross_square,energy_product;
    reg [7:0] lag,lag_r,lag_i;
    reg [47:0] ar1,ar2,ai1,ai2;
    reg signed [47:0] cr,ci;
    reg [10:0] best_r,best_i;
    reg found_r,found_i;
    reg [7:0] scan;
    reg [7:0] radius,gap;
    reg signed [19:0] centre,left_max,right_max;
    reg [9:0] last_peak;
    reg have_peak;
    reg [5:0] interval_count,good_count,sort_a,sort_b;
    reg [11:0] median2,good_median2;
    reg [31:0] rr_sum,rr_sum2;
    reg [63:0] variance,norm_square;
    reg [11:0] peak_bpm10,acf_bpm10,previous10;
    reg previous_valid;
    reg divide_start;
    reg [63:0] numerator,denominator;
    wire [63:0] quotient;
    wire divide_done;
    wire clear_math=!enable || (tick && (!contact || discontinuity));
    pulse_divider64 divider(clk,rst_n,clear_math,divide_start,numerator,denominator,quotient,divide_done);

    // Only addresses selected by the current phase are used; edge replication
    // matches the documented finite-window smoothing rule.
    integer read_index;
    always @* begin
        read_index=0;
        if(state==SM_SUM) read_index=$signed({1'b0,index})+$signed({1'b0,offset})-2;
        else if(state==BASE_SUM) read_index=$signed({1'b0,index})+$signed({1'b0,offset})-50;
        else if(state==FIL_SUM) read_index=index+offset-20;
        if(read_index<0) read_index=0;
        if(read_index>799) read_index=799;
    end
    wire signed [18:0] r0=sig_r[index],i0=sig_i[index];
    wire signed [18:0] r1=sig_r[index+lag],i1=sig_i[index+lag];
    wire signed [37:0] r0sq=r0*r0,i0sq=i0*i0,r1sq=r1*r1,i1sq=i1*i1;
    wire signed [37:0] rc=r0*r1,ic=i0*i1,channels=r0*i0;
    wire [102:0] cross_scaled=cross_square*7'd100;
    wire [101:0] energy_scaled=energy_product*6'd49;
    wire [31:0] base_r=sum_r/101,base_i=sum_i/101;
    wire local_r=(scan>0 && scan<141 && score_r[scan]>score_r[scan-1] && score_r[scan]>=score_r[scan+1]);
    wire local_i=(scan>0 && scan<141 && score_i[scan]>score_i[scan-1] && score_i[scan]>=score_i[scan+1]);
    wire signed [19:0] lp=left_max-centre,rp=right_max-centre;
    wire signed [19:0] prominence=(lp<rp)?lp:rp;
    wire signed [39:0] centre2=centre*centre,prominence2=prominence*prominence;
    wire [63:0] amplitude_test=$unsigned(centre2)*64'd18000;
    wire [63:0] prominence_test=$unsigned(prominence2)*64'd18000;
    wire [11:0] interval2={1'b0,rr[index],1'b0};
    wire [11:0] median_distance=(interval2>median2)?interval2-median2:median2-interval2;
    wire [31:0] norm=good_count*good_median2;
    wire [63:0] var_term=good_count*64'(rr_sum2)-64'(rr_sum)*rr_sum;
    wire [11:0] agreement=(peak_bpm10>acf_bpm10)?peak_bpm10-acf_bpm10:acf_bpm10-peak_bpm10;
    wire [31:0] allowed_delta=(acf_bpm10*8/100>50)?acf_bpm10*8/100:50;
    wire [11:0] previous_delta=(peak_bpm10>previous10)?peak_bpm10-previous10:previous10-peak_bpm10;
    // RAM contents are never reset. Full-window counters guarantee initialization
    // before any value is used; writes have a synchronous enable, not async reset.
    always @(posedge clk) begin
        if(rst_n && enable && age<CLK_HZ && !(tick && (!contact || discontinuity))) begin
            if(tick) begin ring_r[pointer]<=red;ring_i[pointer]<=ir;end
            if(state==COPY) begin raw_r[index]<=ring_r[copy_pointer];raw_i[index]<=ring_i[copy_pointer];end
            if(state==SM_STORE) begin sm_r[index]<=sum_r/5;sm_i[index]<=sum_i/5;end
            if(state==FIL_STORE) begin
                sig_r[index-40]<=$signed({1'b0,sm_r[index]})-$signed(sum_r/41);
                sig_i[index-40]<=$signed({1'b0,sm_i[index]})-$signed(sum_i/41);
            end
            if(state==WAIT_R && divide_done) score_r[lag-30]<=quotient[10:0];
            if(state==WAIT_I && divide_done) score_i[lag-30]<=quotient[10:0];
            if(state==PEAK_STORE && amplitude_test>energy_i && prominence>0 &&
                prominence_test>64'(energy_i)*4 && (!have_peak || index-last_peak>=gap) && have_peak && interval_count<40)
                rr[interval_count]<=index-last_peak;
            if(state==SORT && rr[sort_b]>rr[sort_b+1]) begin rr[sort_b]<=rr[sort_b+1];rr[sort_b+1]<=rr[sort_b];end
            if(state==GOOD && median_distance*5<=median2) good_rr[good_count]<=rr[index];
        end
    end
    // Synchronous reset allows DSP accumulator registers to use PREG safely.
    always @(posedge clk) begin
        if(!rst_n) begin
            state<=IDLE;pointer<=0;filled<=0;hop<=0;copy_pointer<=0;index<=0;offset<=0;
            expected_sequence<=0;age<=0;have_sequence<=0;bpm<=0;valid<=0;
            analysis_done<=0;candidate10<=0;previous10<=0;previous_valid<=0;
            sum_r<=0;sum_i<=0;dc_r<=0;dc_i<=0;min_r<=0;max_r<=0;min_i<=0;max_i<=0;
            energy_r<=0;energy_i<=0;cross_sum<=0;cross_square<=0;energy_product<=0;
            lag<=30;lag_r<=0;lag_i<=0;ar1<=0;ar2<=0;ai1<=0;ai2<=0;cr<=0;ci<=0;
            best_r<=0;best_i<=0;found_r<=0;found_i<=0;scan<=0;radius<=0;gap<=0;
            centre<=0;left_max<=0;right_max<=0;last_peak<=0;have_peak<=0;
            interval_count<=0;good_count<=0;sort_a<=0;sort_b<=0;median2<=0;good_median2<=0;
            rr_sum<=0;rr_sum2<=0;variance<=0;norm_square<=0;peak_bpm10<=0;acf_bpm10<=0;
            divide_start<=0;numerator<=0;denominator<=1;
        end else begin
            analysis_done<=0;divide_start<=0;
            if(!enable || age>=CLK_HZ || (tick && (!contact || discontinuity))) begin
                state<=IDLE;pointer<=0;filled<=0;hop<=0;valid<=0;bpm<=0;
                previous_valid<=0;candidate10<=0;age<=0;
                have_sequence<=tick && enable;
                if(tick) expected_sequence<=sequence_number+1'b1;
            end else begin
                if(age<CLK_HZ) age<=age+1'b1;
                if(tick) begin
                    age<=0;have_sequence<=1;expected_sequence<=sequence_number+1'b1;
                    pointer<=(pointer==799)?0:pointer+1'b1;
                    if(filled<800) filled<=filled+1'b1;
                    if(filled==799 || (filled==800 && hop==99)) begin
                        hop<=0;
                        if(state==IDLE) begin
                            copy_pointer<=(pointer==799)?0:pointer+1'b1;
                            index<=0;dc_r<=0;dc_i<=0;state<=COPY;
                        end
                    end else if(filled==800) hop<=hop+1'b1;
                end
                case(state)
                    IDLE: ;
                    COPY: begin
                        dc_r<=dc_r+ring_r[copy_pointer];dc_i<=dc_i+ring_i[copy_pointer];
                        copy_pointer<=(copy_pointer==799)?0:copy_pointer+1'b1;
                        if(index==799) begin index<=0;state<=SM_INIT;end else index<=index+1'b1;
                    end
                    SM_INIT: begin sum_r<=0;sum_i<=0;offset<=0;state<=SM_SUM;end
                    SM_SUM: begin
                        sum_r<=sum_r+raw_r[read_index];sum_i<=sum_i+raw_i[read_index];
                        if(offset==4) state<=SM_STORE;else offset<=offset+1'b1;
                    end
                    SM_STORE: begin
                        if(index==799) begin index<=0;min_r<=262143;min_i<=262143;max_r<=0;max_i<=0;state<=BASE_INIT;end
                        else begin index<=index+1'b1;state<=SM_INIT;end
                    end
                    BASE_INIT: begin sum_r<=0;sum_i<=0;offset<=0;state<=BASE_SUM;end
                    BASE_SUM: begin
                        sum_r<=sum_r+sm_r[read_index];sum_i<=sum_i+sm_i[read_index];
                        if(offset==100) state<=BASE_STORE;else offset<=offset+1'b1;
                    end
                    BASE_STORE: begin
                        if(base_r<min_r) min_r<=base_r;if(base_r>max_r) max_r<=base_r;
                        if(base_i<min_i) min_i<=base_i;if(base_i>max_i) max_i<=base_i;
                        if(index==799) state<=DRIFT;else begin index<=index+1'b1;state<=BASE_INIT;end
                    end
                    DRIFT: if(64'(max_r-min_r)*80000>64'(dc_r)*3 || 64'(max_i-min_i)*80000>64'(dc_i)*3) state<=REJECT;
                        else begin index<=40;state<=FIL_INIT;end
                    FIL_INIT: begin sum_r<=0;sum_i<=0;offset<=0;state<=FIL_SUM;end
                    FIL_SUM: begin
                        sum_r<=sum_r+sm_r[read_index];sum_i<=sum_i+sm_i[read_index];
                        if(offset==40) state<=FIL_STORE;else offset<=offset+1'b1;
                    end
                    FIL_STORE: begin
                        if(index==759) state<=ENERGY_INIT;else begin index<=index+1'b1;state<=FIL_INIT;end
                    end
                    ENERGY_INIT: begin index<=0;energy_r<=0;energy_i<=0;cross_sum<=0;state<=ENERGY_SUM;end
                    ENERGY_SUM: begin
                        energy_r<=energy_r+$unsigned(r0sq);energy_i<=energy_i+$unsigned(i0sq);cross_sum<=cross_sum+channels;
                        if(index==719) state<=ENERGY_PRODUCT;else index<=index+1'b1;
                    end
                    ENERGY_PRODUCT: begin cross_square<=cross_sum*cross_sum;energy_product<=energy_r*energy_i;state<=CROSS_CHECK;end
                    CROSS_CHECK: if(energy_r<11520 || energy_i<11520 || cross_sum<=0 || cross_scaled<energy_scaled) state<=REJECT;
                        else begin lag<=30;state<=AC_INIT;end
                    AC_INIT: begin index<=0;ar1<=0;ar2<=0;ai1<=0;ai2<=0;cr<=0;ci<=0;state<=AC_SUM;end
                    AC_SUM: begin
                        ar1<=ar1+$unsigned(r0sq);ar2<=ar2+$unsigned(r1sq);cr<=cr+rc;
                        ai1<=ai1+$unsigned(i0sq);ai2<=ai2+$unsigned(i1sq);ci<=ci+ic;
                        if(index==719-lag) state<=DIV_R;else index<=index+1'b1;
                    end
                    DIV_R: begin numerator<=(cr>0)?64'(cr)*2000:0;denominator<=ar1+ar2;divide_start<=1;state<=WAIT_R;end
                    WAIT_R: if(divide_done) begin state<=DIV_I;end
                    DIV_I: begin numerator<=(ci>0)?64'(ci)*2000:0;denominator<=ai1+ai2;divide_start<=1;state<=WAIT_I;end
                    WAIT_I: if(divide_done) begin
                        if(lag==171) begin scan<=1;best_r<=0;best_i<=0;state<=FIND_BEST;end
                        else begin lag<=lag+1'b1;state<=AC_INIT;end
                    end
                    FIND_BEST: begin
                        if(local_r && score_r[scan]>best_r) best_r<=score_r[scan];
                        if(local_i && score_i[scan]>best_i) best_i<=score_i[scan];
                        if(scan==140) begin scan<=1;found_r<=0;found_i<=0;state<=FIND_FIRST;end else scan<=scan+1'b1;
                    end
                    FIND_FIRST: begin
                        if(!found_r && local_r && score_r[scan]>=450 && score_r[scan]*10>=best_r*9) begin found_r<=1;lag_r<=scan+30;end
                        if(!found_i && local_i && score_i[scan]>=450 && score_i[scan]*10>=best_i*9) begin found_i<=1;lag_i<=scan+30;end
                        if(scan==140) state<=PERIOD_CHECK;else scan<=scan+1'b1;
                    end
                    PERIOD_CHECK: if(!found_r || !found_i || score_i[lag_i-30]<600 || 6000*((lag_r>lag_i)?lag_r-lag_i:lag_i-lag_r)>5*lag_r*lag_i) state<=REJECT;
                        else begin radius<=(lag_i*3+5)/10;gap<=(lag_i*6+9)/10;state<=PEAK_INIT;end
                    PEAK_INIT: begin index<=radius;interval_count<=0;have_peak<=0;state<=PEAK_TEST;end
                    PEAK_TEST: begin
                        centre<=sig_i[index];left_max<=-524288;right_max<=-524288;offset<=1;
                        if(sig_i[index]<sig_i[index-1] && sig_i[index]<=sig_i[index+1] && sig_i[index]<0) state<=PEAK_RANGE;
                        else if(index==719-radius) state<=SORT_INIT;else index<=index+1'b1;
                    end
                    PEAK_RANGE: begin
                        if(sig_i[index-offset]>left_max) left_max<=sig_i[index-offset];
                        if(sig_i[index+offset]>right_max) right_max<=sig_i[index+offset];
                        if(offset==radius) state<=PEAK_STORE;else offset<=offset+1'b1;
                    end
                    PEAK_STORE: begin
                        if(amplitude_test>energy_i && prominence>0 && prominence_test>64'(energy_i)*4 && (!have_peak || index-last_peak>=gap)) begin
                            if(have_peak && interval_count<40) begin interval_count<=interval_count+1'b1;end
                            last_peak<=index;have_peak<=1;
                        end
                        if(index==719-radius) state<=SORT_INIT;else begin index<=index+1'b1;state<=PEAK_TEST;end
                    end
                    SORT_INIT: if(interval_count<4 || interval_count==40) state<=REJECT;
                        else begin sort_a<=0;sort_b<=0;state<=SORT;end
                    SORT: begin
                        if(sort_b==interval_count-2) begin
                            sort_b<=0;if(sort_a==interval_count-2) state<=MEDIAN;else sort_a<=sort_a+1'b1;
                        end else sort_b<=sort_b+1'b1;
                    end
                    MEDIAN: begin
                        median2<=interval_count[0]?2*rr[interval_count/2]:rr[interval_count/2-1]+rr[interval_count/2];
                        index<=0;good_count<=0;rr_sum<=0;rr_sum2<=0;state<=GOOD;
                    end
                    GOOD: begin
                        if(median_distance*5<=median2) begin
                            good_count<=good_count+1'b1;
                            rr_sum<=rr_sum+rr[index];rr_sum2<=rr_sum2+rr[index]*rr[index];
                        end
                        if(index==interval_count-1) state<=GOOD_CHECK;else index<=index+1'b1;
                    end
                    GOOD_CHECK: if(good_count<4 || good_count*5<interval_count*4) state<=REJECT;
                        else begin good_median2<=good_count[0]?2*good_rr[good_count/2]:good_rr[good_count/2-1]+good_rr[good_count/2];state<=CV_PRODUCT;end
                    CV_PRODUCT: begin variance<=var_term;norm_square<=64'(norm)*norm;state<=CV_CHECK;end
                    CV_CHECK: if(variance*40000>norm_square*144) state<=REJECT;else state<=DIV_PEAK;
                    DIV_PEAK: begin numerator<=120000;denominator<=good_median2;divide_start<=1;state<=WAIT_PEAK;end
                    WAIT_PEAK: if(divide_done) begin peak_bpm10<=quotient[11:0];state<=DIV_AC;end
                    DIV_AC: begin numerator<=60000;denominator<=lag_i;divide_start<=1;state<=WAIT_AC;end
                    WAIT_AC: if(divide_done) begin acf_bpm10<=quotient[11:0];state<=FINISH;end
                    FINISH: begin
                        analysis_done<=1;state<=IDLE;
                        if(agreement>allowed_delta || peak_bpm10<350 || peak_bpm10>2000) begin
                            valid<=0;bpm<=0;candidate10<=0;previous_valid<=0;
                        end else begin
                            candidate10<=peak_bpm10;previous10<=peak_bpm10;previous_valid<=1;
                            valid<=previous_valid && previous_delta<=50;
                            bpm<=(previous_valid && previous_delta<=50)?(peak_bpm10+5)/10:0;
                        end
                    end
                    REJECT: begin valid<=0;bpm<=0;candidate10<=0;previous_valid<=0;analysis_done<=1;state<=IDLE;end
                    default: state<=REJECT;
                endcase
            end
        end
    end
endmodule

module pulse_divider64(input wire clk,rst_n,clear,start,
    input wire [63:0] numerator,denominator,output reg [63:0] quotient,output reg done);
    reg [64:0] remainder;
    reg [63:0] divisor,work;
    reg [6:0] count;
    reg active;
    wire [64:0] shifted={remainder[63:0],work[63]};
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin remainder<=0;divisor<=1;work<=0;count<=0;active<=0;quotient<=0;done<=0;end
        else begin
            done<=0;
            if(clear) begin active<=0;count<=0;end
            else if(start && !active) begin
                remainder<=0;divisor<=denominator;work<=numerator;count<=64;active<=1;
                if(denominator==0) begin quotient<=0;active<=0;done<=1;end
            end else if(active) begin
                if(shifted>={1'b0,divisor}) begin remainder<=shifted-divisor;work<={work[62:0],1'b1};end
                else begin remainder<=shifted;work<={work[62:0],1'b0};end
                count<=count-1'b1;
                if(count==1) begin quotient<={work[62:0],shifted>={1'b0,divisor}};active<=0;done<=1;end
            end
        end
    end
endmodule
