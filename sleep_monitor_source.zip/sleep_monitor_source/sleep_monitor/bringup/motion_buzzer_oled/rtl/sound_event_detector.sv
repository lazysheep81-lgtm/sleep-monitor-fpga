`timescale 1ns/1ps
// Experimental sound activity, NOT a snoring classifier or health assessment.
// Sum of squares is compared with RMS^2 * WINDOW_SAMPLES; no square root.
module sound_event_detector #(
    parameter integer CLK_HZ=50_000_000, WINDOW_SAMPLES=781,
    ONSET_RMS=6023, OFFSET_RMS=3614, ATTACK_WINDOWS=3, RELEASE_WINDOWS=5
)(
    input wire clk,rst_n,sample_valid,input wire signed [23:0] sample,
    output reg active,output wire live,output wire fault,
    output reg [23:0] event_count,complete_count,
    output reg [31:0] duration_samples,total_samples
);
    localparam integer CW=(WINDOW_SAMPLES<=1)?1:$clog2(WINDOW_SAMPLES);
    localparam [63:0] ONSET_ENERGY=64'(ONSET_RMS)*ONSET_RMS*WINDOW_SAMPLES;
    localparam [63:0] OFFSET_ENERGY=64'(OFFSET_RMS)*OFFSET_RMS*WINDOW_SAMPLES;
    reg square_valid,square_zero,square_clip;
    reg [47:0] square;
    always @(posedge clk) begin
        if(!rst_n) begin square_valid<=0;square<=0;square_zero<=0;square_clip<=0;end
        else begin
            square_valid<=sample_valid;
            if(sample_valid) begin
                square<=$signed(sample)*$signed(sample);
                square_zero<=(sample==0);
                square_clip<=(sample>=24'sh7ffff0 || sample<=-24'sd8388592);
            end
        end
    end
    reg [CW-1:0] in_window;
    reg [57:0] sum_square;
    wire [57:0] energy=sum_square+{10'b0,square};
    reg all_zero,any_clip,have_window,window_good,segment_start;
    reg [31:0] age,elapsed;
    reg [7:0] attack,release_count;
    reg pending_boundary,active_boundary;
    wire timeout=(age>=CLK_HZ/2);
    assign live=have_window && window_good && !timeout;
    assign fault=have_window && (!window_good || timeout);
    function [31:0] add_window(input [31:0] value);
        begin add_window=(value>32'hffffffff-WINDOW_SAMPLES)?32'hffffffff:value+WINDOW_SAMPLES;end
    endfunction
    always @(posedge clk) begin
        if(!rst_n) begin
            active<=0;event_count<=0;complete_count<=0;duration_samples<=0;total_samples<=0;
            in_window<=0;sum_square<=0;all_zero<=1;any_clip<=0;have_window<=0;window_good<=0;
            segment_start<=1;age<=0;elapsed<=0;attack<=0;release_count<=0;
            pending_boundary<=1;active_boundary<=1;
        end else begin
            if(sample_valid) age<=0;else if(age<CLK_HZ/2) age<=age+1'b1;
            if(timeout && !sample_valid) begin
                active<=0;attack<=0;release_count<=0;segment_start<=1;
                in_window<=0;sum_square<=0;all_zero<=1;any_clip<=0;
            end
            if(square_valid) begin
                total_samples<=total_samples+1'b1;
                if(in_window==WINDOW_SAMPLES-1) begin
                    in_window<=0;sum_square<=0;all_zero<=1;any_clip<=0;
                    have_window<=1;
                    window_good<=!((all_zero && square_zero) || any_clip || square_clip);
                    if((all_zero && square_zero) || any_clip || square_clip) begin
                        active<=0;attack<=0;release_count<=0;segment_start<=1;
                    end else begin
                        segment_start<=0;
                        if(!active) begin
                            if(energy>=ONSET_ENERGY) begin
                                if(attack==0) pending_boundary<=segment_start;
                                if(attack==ATTACK_WINDOWS-1) begin
                                    active<=1;attack<=0;release_count<=0;
                                    active_boundary<=(attack==0)?segment_start:pending_boundary;
                                    elapsed<=ATTACK_WINDOWS*WINDOW_SAMPLES;
                                    duration_samples<=ATTACK_WINDOWS*WINDOW_SAMPLES;
                                    if(event_count!=24'hffffff) event_count<=event_count+1'b1;
                                end else attack<=attack+1'b1;
                            end else attack<=0;
                        end else begin
                            elapsed<=add_window(elapsed);
                            if(energy>=OFFSET_ENERGY) begin
                                release_count<=0;duration_samples<=add_window(elapsed);
                            end else if(release_count==RELEASE_WINDOWS-1) begin
                                active<=0;attack<=0;release_count<=0;
                                if(!active_boundary && complete_count!=24'hffffff)
                                    complete_count<=complete_count+1'b1;
                            end else release_count<=release_count+1'b1;
                        end
                    end
                end else begin
                    in_window<=in_window+1'b1;sum_square<=energy;
                    all_zero<=all_zero && square_zero;any_clip<=any_clip || square_clip;
                end
            end
        end
    end
endmodule

// Sample count -> centiseconds, updated repeatedly with a serial unsigned
// divider. The divider's input is captured atomically; no long combinational /.
module samples_to_centiseconds #(parameter integer SAMPLE_RATE=15625)(
    input wire clk,rst_n,input wire [31:0] samples,output reg [23:0] centiseconds
);
    reg busy;
    reg [5:0] remaining;
    reg [38:0] numerator,quotient;
    reg [32:0] remainder_value;
    wire [32:0] trial={remainder_value[31:0],numerator[38]};
    wire subtract=(trial>=SAMPLE_RATE);
    wire [38:0] next_q={quotient[37:0],subtract};
    always @(posedge clk) begin
        if(!rst_n) begin busy<=0;remaining<=0;numerator<=0;quotient<=0;remainder_value<=0;centiseconds<=0;end
        else if(!busy) begin
            numerator<=39'(samples)*39'd100;quotient<=0;remainder_value<=0;
            remaining<=39;busy<=1;
        end else begin
            numerator<={numerator[37:0],1'b0};quotient<=next_q;
            remainder_value<=subtract?trial-SAMPLE_RATE:trial;
            remaining<=remaining-1'b1;
            if(remaining==1) begin
                centiseconds<=(next_q>24'hffffff)?24'hffffff:next_q[23:0];busy<=0;
            end
        end
    end
endmodule
