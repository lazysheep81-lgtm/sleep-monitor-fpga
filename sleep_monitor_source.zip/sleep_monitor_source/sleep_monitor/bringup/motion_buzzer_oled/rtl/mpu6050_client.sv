`timescale 1ns/1ps
// Separate I2C bus, MPU6050 only. No assumptions about the other GY-87 chips.
module mpu6050_client #(parameter integer CLK_HZ=50_000_000)(
    input wire clk,rst_n,
    output reg start,reading,output reg [6:0] address,
    output reg [7:0] reg_addr,write_data,output reg [2:0] length,
    input wire done,input wire [47:0] data,input wire [2:0] bus_error,
    output reg configured,sample_valid,output wire live,
    output reg signed [15:0] ax,ay,az,gx,gy,gz,
    output reg [3:0] error_code
);
    localparam BOOT=0,ID_REQ=1,ID_WAIT=2,WR_REQ=3,WR_WAIT=4,
        SETTLE=5,CHECK_REQ=6,CHECK_WAIT=7,POLL=8,STATUS_WAIT=9,
        ACC_REQ=10,ACC_WAIT=11,GYR_REQ=12,GYR_WAIT=13,RETRY=14;
    reg [3:0] state;
    reg [2:0] step;
    reg [31:0] delay_count,age;
    reg have_sample;
    reg [47:0] pending_accel;
    assign live=configured && have_sample && age<CLK_HZ/2;
    function [7:0] init_reg(input [2:0] n);
        case(n) 0:init_reg=8'h6b;1:init_reg=8'h19;2:init_reg=8'h1a;
            3:init_reg=8'h1b;default:init_reg=8'h1c;endcase
    endfunction
    function [7:0] init_value(input [2:0] n);
        case(n) 0:init_value=1;1:init_value=19;2:init_value=3;default:init_value=0;endcase
    endfunction
    task request(input rd,input [7:0] regnum,value,input [2:0] bytes,input [3:0] next_state);
        begin start<=1;reading<=rd;reg_addr<=regnum;write_data<=value;length<=bytes;state<=next_state;end
    endtask
    task fail(input [3:0] code);
        begin configured<=0;have_sample<=0;error_code<=code;delay_count<=CLK_HZ-1;state<=RETRY;end
    endtask
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            start<=0;reading<=0;address<=7'h68;reg_addr<=0;write_data<=0;length<=1;
            configured<=0;sample_valid<=0;have_sample<=0;error_code<=0;
            ax<=0;ay<=0;az<=0;gx<=0;gy<=0;gz<=0;pending_accel<=0;
            state<=BOOT;step<=0;delay_count<=CLK_HZ/10-1;age<=CLK_HZ/2;
        end else begin
            start<=0;sample_valid<=0;
            if(age<CLK_HZ/2) age<=age+1'b1;
            if(configured && age>=CLK_HZ/2) fail(4'd10);
            else case(state)
                BOOT,RETRY: if(delay_count!=0) delay_count<=delay_count-1'b1;
                    else begin address<=7'h68;state<=ID_REQ;end
                ID_REQ: request(1,8'h75,0,1,ID_WAIT);
                ID_WAIT: if(done) begin
                    if(bus_error!=0 || data[7:0]!=8'h68) begin
                        if(address==7'h68) begin address<=7'h69;state<=ID_REQ;end
                        else fail(bus_error!=0?{1'b0,bus_error}:4'd8);
                    end else begin step<=0;state<=WR_REQ;end
                end
                WR_REQ: request(0,init_reg(step),init_value(step),1,WR_WAIT);
                WR_WAIT: if(done) begin
                    if(bus_error!=0) fail({1'b0,bus_error});
                    else if(step==0) begin delay_count<=CLK_HZ/10-1;state<=SETTLE;end
                    else state<=CHECK_REQ;
                end
                SETTLE: if(delay_count!=0) delay_count<=delay_count-1'b1;else state<=CHECK_REQ;
                CHECK_REQ: request(1,init_reg(step),0,1,CHECK_WAIT);
                CHECK_WAIT: if(done) begin
                    if(bus_error!=0) fail({1'b0,bus_error});
                    else if(data[7:0]!=init_value(step)) fail(4'd9);
                    else if(step==4) begin configured<=1;age<=0;error_code<=0;delay_count<=CLK_HZ/50-1;state<=POLL;end
                    else begin step<=step+1'b1;state<=WR_REQ;end
                end
                POLL: if(delay_count!=0) delay_count<=delay_count-1'b1;
                    else request(1,8'h3a,0,1,STATUS_WAIT);
                STATUS_WAIT: if(done) begin
                    if(bus_error!=0) fail({1'b0,bus_error});
                    else if(!data[0]) begin delay_count<=CLK_HZ/1000-1;state<=POLL;end
                    else state<=ACC_REQ;
                end
                ACC_REQ: request(1,8'h3b,0,6,ACC_WAIT);
                ACC_WAIT: if(done) begin
                    if(bus_error!=0) fail({1'b0,bus_error});
                    else begin pending_accel<=data;state<=GYR_REQ;end
                end
                GYR_REQ: request(1,8'h43,0,6,GYR_WAIT);
                GYR_WAIT: if(done) begin
                    if(bus_error!=0) fail({1'b0,bus_error});
                    else begin
                        ax<=pending_accel[47:32];ay<=pending_accel[31:16];az<=pending_accel[15:0];
                        gx<=data[47:32];gy<=data[31:16];gz<=data[15:0];
                        sample_valid<=1;have_sample<=1;age<=0;
                        delay_count<=CLK_HZ/50-1;state<=POLL;
                    end
                end
                default: fail(4'd15);
            endcase
        end
    end
endmodule
