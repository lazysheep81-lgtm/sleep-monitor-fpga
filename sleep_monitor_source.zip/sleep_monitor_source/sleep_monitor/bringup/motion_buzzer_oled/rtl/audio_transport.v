`timescale 1ns/1ps
// Native 24-bit PCM, indexed before queueing. Overflow is counted, never hidden.
module native_audio_fifo #(parameter integer ADDRESS_BITS=10)(
    input wire clk,rst_n,input wire valid,input wire [23:0] sample,input wire pop,
    output wire [55:0] head,output reg [ADDRESS_BITS:0] level,
    output reg [31:0] dropped
);
    reg [55:0] memory[0:(1<<ADDRESS_BITS)-1];
    reg [ADDRESS_BITS-1:0] wr,rd;
    reg [31:0] next_index;
    wire take=pop && level!=0;
    wire put=valid && (level<(1<<ADDRESS_BITS) || take);
    assign head=memory[rd];
    always @(posedge clk) if(rst_n && put) memory[wr]<={next_index,sample};
    always @(posedge clk) begin
        if(!rst_n) begin wr<=0;rd<=0;level<=0;next_index<=0;dropped<=0;end
        else begin
            if(valid) begin
                next_index<=next_index+1'b1;
                if(!put) dropped<=dropped+1'b1;
            end
            if(put) wr<=wr+1'b1;
            if(take) rd<=rd+1'b1;
            case({put,take})
                2'b10:level<=level+1'b1;
                2'b01:level<=level-1'b1;
            endcase
        end
    end
endmodule

// Frame: 7E, escaped("SM", version=1, type, payload, CRC16 big endian), 7E.
// Escape 7E/7D as 7D followed by byte XOR 20. CRC=CCITT-FALSE, init FFFF.
module audio_transport #(
    parameter integer CLK_HZ=50_000_000,BAUD=1_000_000,
    SAMPLE_RATE=15625,BLOCK_SAMPLES=128,FIFO_ADDRESS_BITS=10
)(
    input wire clk,rst_n,input wire audio_valid,input wire [23:0] audio_sample,
    input wire ppg_valid,output wire ppg_ready,
    input wire [31:0] ppg_sequence,input wire [17:0] red,ir,
    input wire status_valid,output wire status_ready,
    input wire [3:0] status_error,input wire [7:0] status_register,status_value,
    input wire mic_valid,output wire mic_ready,
    input wire [31:0] mic_sequence,input wire [23:0] mic_minimum,mic_maximum,mic_mean,
    input wire [10:0] mic_zeros,mic_clipped,input wire [15:0] mic_skipped,
    input wire [7:0] bpm,input wire bpm_valid,input wire [1:0] recovery_flags,
    input wire [23:0] event_count,event_complete_count,
    input wire [31:0] event_duration,event_total_samples,input wire [2:0] event_flags,
    output wire txd,output wire [31:0] dropped
);
    localparam IDLE=0,META=1,FETCH=2,PCM0=3,PCM1=4,PCM2=5,AUDIO_FINISH=6,
        CRC_INIT=7,CRC_SCAN=8,CRC_HIGH=9,CRC_LOW=10,OPEN=11,BODY=12,ESCAPE=13,CLOSE=14;
    reg [3:0] state;
    reg [7:0] packet[0:511];
    reg [239:0] metadata;
    reg [8:0] position,payload_length,packet_length;
    reg [5:0] meta_length;
    reg [7:0] sample_number;
    reg [23:0] current_sample;
    reg [31:0] first_index;
    reg audio_packet,noncontiguous;
    reg event_pending;
    reg [239:0] event_metadata;
    reg pop;
    wire [55:0] head;
    wire [FIFO_ADDRESS_BITS:0] level;
    native_audio_fifo #(.ADDRESS_BITS(FIFO_ADDRESS_BITS)) fifo(clk,rst_n,audio_valid,audio_sample,pop,head,level,dropped);
    wire idle=(state==IDLE);
    assign status_ready=idle;
    assign ppg_ready=idle && !status_valid;
    assign mic_ready=idle && !status_valid && !ppg_valid;
    reg tx_start;reg [7:0] tx_data;wire tx_busy;
    wire byte_ready=!tx_busy && !tx_start;
    uart_tx #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) serial(clk,rst_n,tx_start,tx_data,txd,tx_busy);
    function [31:0] le32(input [31:0] x);begin le32={x[7:0],x[15:8],x[23:16],x[31:24]};end endfunction
    function [23:0] le24(input [23:0] x);begin le24={x[7:0],x[15:8],x[23:16]};end endfunction
    function [15:0] le16(input [15:0] x);begin le16={x[7:0],x[15:8]};end endfunction
    function [15:0] crc_byte(input [15:0] old,input [7:0] value);
        reg [15:0] c;integer i;
        begin c=old^{value,8'b0};for(i=0;i<8;i=i+1) c=c[15]?(c<<1)^16'h1021:(c<<1);crc_byte=c;end
    endfunction
    reg [15:0] crc;
    wire [7:0] meta_byte=metadata >> ((29-position)*8);
    wire [7:0] packet_byte=packet[position];
    // One memory write per cycle. Packet memory contents do not need reset.
    always @(posedge clk) if(rst_n) begin
        case(state)
            META:packet[position]<=meta_byte;
            PCM0:packet[position]<=current_sample[7:0];
            PCM1:packet[position]<=current_sample[15:8];
            PCM2:packet[position]<=current_sample[23:16];
            AUDIO_FINISH:packet[14]<={7'b0,noncontiguous};
            CRC_HIGH:packet[payload_length]<=crc[15:8];
            CRC_LOW:packet[payload_length+1'b1]<=crc[7:0];
        endcase
    end
    always @(posedge clk) begin
        if(!rst_n) begin
            state<=IDLE;metadata<=0;position<=0;payload_length<=0;packet_length<=0;
            meta_length<=0;sample_number<=0;current_sample<=0;first_index<=0;
            audio_packet<=0;noncontiguous<=0;pop<=0;tx_start<=0;tx_data<=0;crc<=16'hffff;
            event_pending<=0;event_metadata<=0;
        end else begin
            pop<=0;tx_start<=0;
            case(state)
                IDLE:begin
                    position<=0;audio_packet<=0;noncontiguous<=0;
                    if(status_valid) begin
                        metadata<={"SM",8'd1,8'd3,{4'b0,status_error},status_register,status_value,184'b0};
                        meta_length<=7;payload_length<=7;state<=META;
                    end else if(ppg_valid) begin
                        metadata<={"SM",8'd1,8'd2,le32(ppg_sequence),le24({6'b0,red}),le24({6'b0,ir}),128'b0};
                        meta_length<=14;payload_length<=14;state<=META;
                    end else if(mic_valid) begin
                        metadata<={"SM",8'd1,8'd4,le32(mic_sequence),le24(mic_minimum),le24(mic_maximum),le24(mic_mean),
                            le16({5'b0,mic_zeros}),le16({5'b0,mic_clipped}),le16(mic_skipped),bpm,{7'b0,bpm_valid},
                            {6'b0,recovery_flags},le32(dropped)};
                        meta_length<=30;payload_length<=30;state<=META;
                        event_metadata<={"SM",8'd1,8'd5,le32(mic_sequence),le24(event_count),le24(event_complete_count),
                            le32(event_duration),{5'b0,event_flags},le32(event_total_samples),56'b0};
                        event_pending<=1;
                    end else if(event_pending) begin
                        metadata<=event_metadata;event_pending<=0;
                        meta_length<=23;payload_length<=23;state<=META;
                    end else if(level>=BLOCK_SAMPLES) begin
                        metadata<={"SM",8'd1,8'd1,le32(head[55:24]),le32(SAMPLE_RATE),le16(BLOCK_SAMPLES),8'd0,le32(dropped),88'b0};
                        first_index<=head[55:24];sample_number<=0;audio_packet<=1;
                        meta_length<=19;payload_length<=19+3*BLOCK_SAMPLES;state<=META;
                    end
                end
                META:begin
                    position<=position+1'b1;
                    if(position==meta_length-1) state<=audio_packet?FETCH:CRC_INIT;
                end
                FETCH:begin
                    current_sample<=head[23:0];pop<=1;
                    if(head[55:24]!=(first_index+sample_number)) noncontiguous<=1;
                    state<=PCM0;
                end
                PCM0:begin position<=position+1'b1;state<=PCM1;end
                PCM1:begin position<=position+1'b1;state<=PCM2;end
                PCM2:begin
                    position<=position+1'b1;sample_number<=sample_number+1'b1;
                    state<=(sample_number==BLOCK_SAMPLES-1)?AUDIO_FINISH:FETCH;
                end
                AUDIO_FINISH:state<=CRC_INIT;
                CRC_INIT:begin position<=0;crc<=16'hffff;state<=CRC_SCAN;end
                CRC_SCAN:begin
                    crc<=crc_byte(crc,packet_byte);position<=position+1'b1;
                    if(position==payload_length-1) state<=CRC_HIGH;
                end
                CRC_HIGH:state<=CRC_LOW;
                CRC_LOW:begin packet_length<=payload_length+2;position<=0;state<=OPEN;end
                OPEN:if(byte_ready) begin tx_data<=8'h7e;tx_start<=1;state<=BODY;end
                BODY:if(byte_ready) begin
                    tx_start<=1;
                    if(packet_byte==8'h7e || packet_byte==8'h7d) begin tx_data<=8'h7d;state<=ESCAPE;end
                    else begin
                        tx_data<=packet_byte;position<=position+1'b1;
                        if(position==packet_length-1) state<=CLOSE;
                    end
                end
                ESCAPE:if(byte_ready) begin
                    tx_data<=packet_byte^8'h20;tx_start<=1;position<=position+1'b1;
                    state<=(position==packet_length-1)?CLOSE:BODY;
                end
                CLOSE:if(byte_ready) begin tx_data<=8'h7e;tx_start<=1;state<=IDLE;end
                default:state<=IDLE;
            endcase
        end
    end
endmodule
