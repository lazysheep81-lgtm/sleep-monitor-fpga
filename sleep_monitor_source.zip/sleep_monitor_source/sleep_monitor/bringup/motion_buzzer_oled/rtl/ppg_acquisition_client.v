`timescale 1ns/1ps
// Register configuration and FIFO acquisition only. No synthetic PPG source.
module ppg_acquisition_client #(parameter integer CLK_HZ=50_000_000)(
    input wire clk,input wire rst_n,
    output reg bus_start,output reg bus_read,
    output reg [7:0] bus_register,bus_write,output reg [2:0] bus_length,
    input wire bus_done,input wire [47:0] bus_data,input wire [2:0] bus_error,
    output reg configured,
    output reg sample_valid,input wire sample_ready,
    output reg [17:0] red,ir,output reg [31:0] sequence_number,
    output reg status_valid,input wire status_ready,
    output reg [3:0] status_error,output reg [7:0] status_register,status_value
);
    localparam BOOT=0,ID_REQ=1,ID_WAIT=2,RESET_REQ=3,RESET_WAIT=4,
        RESET_DELAY=5,RESET_CHECK=6,RESET_RESULT=7,CONFIG_REQ=8,CONFIG_WAIT=9,
        VERIFY_REQ=10,VERIFY_WAIT=11,POLL_DELAY=12,POLL_REQ=13,POLL_WAIT=14,
        FIFO_REQ=15,FIFO_WAIT=16,DELIVER=17,RETRY=18;
    reg [4:0] state;
    reg [31:0] delay_count,empty_count;
    reg [3:0] config_index;
    function [15:0] configuration;
        input [3:0] index;
        begin
            case(index)
                0: configuration=16'h0200; // interrupts disabled, poll FIFO
                1: configuration=16'h0300;
                2: configuration=16'h0983; // shutdown, two-channel mode selected
                3: configuration=16'h0400; // FIFO pointers and overflow cleared
                4: configuration=16'h0500;
                5: configuration=16'h0600;
                6: configuration=16'h080f; // no averaging; stop on full
                7: configuration=16'h0a27; // 4096 nA, 100 samples/s, 411 us /18 bit
                8: configuration=16'h0c24; // red LED nominal 7.2 mA
                9: configuration=16'h0d24; // IR LED nominal 7.2 mA
                default: configuration=16'h0903; // start red + IR
            endcase
        end
    endfunction
    wire [15:0] config_word=configuration(config_index);
    task launch;
        input reading;
        input [7:0] address,value;
        input [2:0] length;
        input [4:0] next_state;
        begin
            bus_read<=reading;bus_register<=address;bus_write<=value;
            bus_length<=length;bus_start<=1;state<=next_state;
        end
    endtask
    task fail;
        input [3:0] code;
        begin
            configured<=0;sample_valid<=0;status_valid<=1;
            status_error<=code;status_register<=bus_register;status_value<=bus_data[7:0];
            delay_count<=CLK_HZ-1;state<=RETRY;
        end
    endtask
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=BOOT;delay_count<=CLK_HZ/20-1;empty_count<=0;config_index<=0;
            configured<=0;sample_valid<=0;red<=0;ir<=0;sequence_number<=0;
            status_valid<=0;status_error<=0;status_register<=0;status_value<=0;
            bus_start<=0;bus_read<=0;bus_register<=0;bus_write<=0;bus_length<=1;
        end else begin
            bus_start<=0;
            if(status_valid && status_ready) status_valid<=0;
            case(state)
                BOOT,RESET_DELAY,RETRY: begin
                    if(delay_count!=0) delay_count<=delay_count-1'b1;
                    else if(state==RESET_DELAY) state<=RESET_CHECK;
                    else state<=ID_REQ;
                end
                ID_REQ: launch(1,8'hff,0,1,ID_WAIT);
                ID_WAIT: if(bus_done) begin
                    if(bus_error!=0) fail({1'b0,bus_error});
                    else if(bus_data[7:0]!=8'h15) fail(6);
                    else state<=RESET_REQ;
                end
                RESET_REQ: launch(0,8'h09,8'h40,1,RESET_WAIT);
                RESET_WAIT: if(bus_done) begin
                    if(bus_error!=0) fail({1'b0,bus_error});
                    else begin delay_count<=CLK_HZ/20-1;state<=RESET_DELAY;end
                end
                RESET_CHECK: launch(1,8'h09,0,1,RESET_RESULT);
                RESET_RESULT: if(bus_done) begin
                    if(bus_error!=0) fail({1'b0,bus_error});
                    else if(bus_data[6]) fail(9);
                    else begin config_index<=0;state<=CONFIG_REQ;end
                end
                CONFIG_REQ: launch(0,config_word[15:8],config_word[7:0],1,CONFIG_WAIT);
                CONFIG_WAIT: if(bus_done) begin
                    if(bus_error!=0) fail({1'b0,bus_error});else state<=VERIFY_REQ;
                end
                VERIFY_REQ: launch(1,config_word[15:8],0,1,VERIFY_WAIT);
                VERIFY_WAIT: if(bus_done) begin
                    if(bus_error!=0) fail({1'b0,bus_error});
                    else if(bus_data[7:0]!=config_word[7:0]) fail(7);
                    else if(config_index==10) begin
                        configured<=1;status_valid<=1;status_error<=0;
                        status_register<=8'h09;status_value<=8'h03;
                        delay_count<=CLK_HZ/500-1;empty_count<=0;state<=POLL_DELAY;
                    end else begin config_index<=config_index+1'b1;state<=CONFIG_REQ;end
                end
                POLL_DELAY: if(delay_count!=0) delay_count<=delay_count-1'b1;else state<=POLL_REQ;
                POLL_REQ: launch(1,8'h04,0,3,POLL_WAIT);
                POLL_WAIT: if(bus_done) begin
                    if(bus_error!=0) fail({1'b0,bus_error});
                    else if(bus_data[12:8]!=0) fail(8); // any FIFO overflow invalidates timing
                    else if(bus_data[20:16]!=bus_data[4:0]) begin empty_count<=0;state<=FIFO_REQ;end
                    else if(empty_count==499) fail(10); // ~1.3 s with no samples
                    else begin empty_count<=empty_count+1'b1;delay_count<=CLK_HZ/500-1;state<=POLL_DELAY;end
                end
                // Leave FIFO contents untouched until UART can accept a complete sample.
                FIFO_REQ: if(sample_ready) launch(1,8'h07,0,6,FIFO_WAIT);
                FIFO_WAIT: if(bus_done) begin
                    if(bus_error!=0) fail({1'b0,bus_error});
                    else begin red<=bus_data[41:24];ir<=bus_data[17:0];sample_valid<=1;state<=DELIVER;end
                end
                DELIVER: if(sample_valid && sample_ready) begin
                    sample_valid<=0;sequence_number<=sequence_number+1'b1;
                    delay_count<=CLK_HZ/500-1;state<=POLL_DELAY;
                end
                default: fail(10);
            endcase
        end
    end
endmodule
