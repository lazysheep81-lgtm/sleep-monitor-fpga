`timescale 1ns/1ps
// Convert one stable 24-bit display value in 24 clocks, avoiding a long divider
// in the OLED address path. FPGA INIT gives a valid decimal zero at power-up.
module binary24_bcd(input wire clk,input wire [23:0] value,output reg [31:0] decimal=0);
    reg [23:0] source=0,binary_shift=0;
    reg [31:0] bcd=0;
    reg [4:0] remaining=0;
    reg [31:0] corrected;
    integer digit;
    always @* begin
        corrected=bcd;
        for(digit=0;digit<8;digit=digit+1)
            if(bcd[digit*4 +: 4]>=5) corrected[digit*4 +: 4]=bcd[digit*4 +: 4]+4'd3;
    end
    always @(posedge clk) begin
        if(remaining!=0) begin
            bcd<={corrected[30:0],binary_shift[23]};
            binary_shift<=binary_shift<<1;
            remaining<=remaining-1'b1;
            if(remaining==1) decimal<={corrected[30:0],binary_shift[23]};
        end else if(value!=source) begin
            source<=value;binary_shift<=value;bcd<=0;remaining<=24;
        end
    end
endmodule
