`timescale 1ns/1ps
// Single system-clock domain. SCK=CLK_HZ/(2*HALF_PERIOD), WS=SCK/64.
// L/R must be tied low. Ignore the I2S delay bit and the inactive right slot.
module i2s_microphone #(
    parameter integer HALF_PERIOD=25, WARMUP_FRAMES=8192
)(
    input wire clk,rst_n,input wire sd,
    output reg sck,ws,output reg signed [23:0] sample,
    output reg sample_valid
);
    localparam integer CW=(HALF_PERIOD<2)?1:$clog2(HALF_PERIOD);
    localparam integer WW=(WARMUP_FRAMES<1)?1:$clog2(WARMUP_FRAMES+1);
    reg [CW-1:0] divider;
    reg [5:0] slot;
    reg [WW-1:0] warmup;
    reg [23:0] shift;
    (* ASYNC_REG="TRUE" *) reg [1:0] sd_sync;
    always @(posedge clk) begin
        if(!rst_n) sd_sync<=0;else sd_sync<={sd_sync[0],sd};
    end
    always @(posedge clk) begin
        if(!rst_n) begin
            divider<=0;slot<=63;sck<=1;ws<=1;warmup<=0;
            shift<=0;sample<=0;sample_valid<=0;
        end else begin
            sample_valid<=0;
            if(divider==HALF_PERIOD-1) begin
                divider<=0;sck<=!sck;
                if(sck) begin
                    slot<=slot+1'b1;
                    if(slot==63) ws<=0;
                    else if(slot==31) ws<=1;
                end else if(slot>=1 && slot<=24) begin
                    shift<={shift[22:0],sd_sync[1]};
                    if(slot==24) begin
                        sample<={shift[22:0],sd_sync[1]};
                        if(warmup<WARMUP_FRAMES) warmup<=warmup+1'b1;
                        else sample_valid<=1;
                    end
                end
            end else divider<=divider+1'b1;
        end
    end
endmodule

// Exact 2**WINDOW_LOG2-sample statistics. No signal detection or health label.
// A blocked UART retains its current packet and counts skipped windows.
module microphone_statistics #(parameter integer WINDOW_LOG2=10)(
    input wire clk,rst_n,input wire sample_valid,
    input wire signed [23:0] sample,input wire ready,
    output reg valid,output reg [31:0] sequence_number,
    output reg signed [23:0] minimum,maximum,
    output reg [23:0] mean_absolute,
    output reg [10:0] zeros,clipped,output reg [15:0] skipped,
    output reg live
);
    reg [WINDOW_LOG2-1:0] count;
    reg [31:0] next_sequence;
    reg signed [23:0] running_min,running_max;
    reg [23+WINDOW_LOG2:0] sum_absolute;
    reg [10:0] zero_count,clip_count;
    wire [23:0] magnitude=sample[23]?(~sample+24'd1):sample;
    wire is_clip=(sample>=24'sh7ffff0 || sample<=24'sh800010);
    wire [23+WINDOW_LOG2:0] total=sum_absolute+magnitude;
    wire signed [23:0] next_min=(count==0 || sample<running_min)?sample:running_min;
    wire signed [23:0] next_max=(count==0 || sample>running_max)?sample:running_max;
    always @(posedge clk) begin
        if(!rst_n) begin
            count<=0;next_sequence<=0;running_min<=0;running_max<=0;
            sum_absolute<=0;zero_count<=0;clip_count<=0;
            valid<=0;sequence_number<=0;minimum<=0;maximum<=0;
            mean_absolute<=0;zeros<=0;clipped<=0;skipped<=0;live<=0;
        end else begin
            if(valid && ready) valid<=0;
            if(sample_valid) begin
                running_min<=next_min;running_max<=next_max;
                if(&count) begin
                    count<=0;sum_absolute<=0;zero_count<=0;clip_count<=0;
                    next_sequence<=next_sequence+1'b1;
                    if(!valid || ready) begin
                        valid<=1;live<=1;sequence_number<=next_sequence;
                        minimum<=next_min;maximum<=next_max;
                        mean_absolute<=total>>WINDOW_LOG2;
                        zeros<=zero_count+(sample==0);
                        clipped<=clip_count+is_clip;
                    end else if(skipped!=16'hffff) skipped<=skipped+1'b1;
                end else begin
                    count<=count+1'b1;sum_absolute<=total;
                    zero_count<=zero_count+(sample==0);clip_count<=clip_count+is_clip;
                end
            end
        end
    end
endmodule
