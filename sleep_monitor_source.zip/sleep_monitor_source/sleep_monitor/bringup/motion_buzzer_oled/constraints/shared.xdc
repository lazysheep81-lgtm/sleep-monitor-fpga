create_clock -period 20.000 -name sys_clk [get_ports sys_clk]
set_property -dict {PACKAGE_PIN U18 IOSTANDARD LVCMOS33} [get_ports sys_clk]
set_property -dict {PACKAGE_PIN N16 IOSTANDARD LVCMOS33} [get_ports sys_rst_n]
set_property -dict {PACKAGE_PIN H15 IOSTANDARD LVCMOS33} [get_ports {led[0]}]
set_property -dict {PACKAGE_PIN L15 IOSTANDARD LVCMOS33} [get_ports {led[1]}]
set_property -dict {PACKAGE_PIN J15 IOSTANDARD LVCMOS33} [get_ports uart_txd]
# J2.3=B35_L15_N=F20; J2.4=B35_L15_P=F19. No internal pull-ups.
# Supply: J2.1=3.3 V, J2.2=GND. Confirm physical pin 1 before wiring.
set_property -dict {PACKAGE_PIN F20 IOSTANDARD LVCMOS33} [get_ports shared_scl]
set_property -dict {PACKAGE_PIN F19 IOSTANDARD LVCMOS33} [get_ports shared_sda]
set_false_path -from [get_ports {sys_rst_n shared_scl shared_sda}]

# Board schematic p4 + core schematic p3, verified 2026-10-24:
# J2.5=B35_L4_N=D20; J2.6=B35_L4_P=D19; J2.7=B35_L1_P=C20.
set_property -dict {PACKAGE_PIN D20 IOSTANDARD LVCMOS33 SLEW SLOW DRIVE 4} [get_ports mic_sck]
set_property -dict {PACKAGE_PIN D19 IOSTANDARD LVCMOS33 SLEW SLOW DRIVE 4} [get_ports mic_ws]
set_property -dict {PACKAGE_PIN C20 IOSTANDARD LVCMOS33 PULLDOWN true} [get_ports mic_sd]
# SD is asynchronous to sys_clk and crosses only through the two-register synchronizer.
set_false_path -from [get_ports mic_sd] -to [get_pins -hier -filter {NAME =~ *sd_sync_reg*/D}]

# Baseboard p4 J2.8/9/10, core p3 Bank35:
# J2.8 B35_L1_N=B20; J2.9 B35_L12_N=K18; J2.10 B35_L12_P=K17.
set_property -dict {PACKAGE_PIN B20 IOSTANDARD LVCMOS33 DRIVE 4 SLEW SLOW} [get_ports ext_beep]
set_property -dict {PACKAGE_PIN K18 IOSTANDARD LVCMOS33} [get_ports imu_scl]
set_property -dict {PACKAGE_PIN K17 IOSTANDARD LVCMOS33} [get_ports imu_sda]
set_property -dict {PACKAGE_PIN L14 IOSTANDARD LVCMOS33 PULLUP true} [get_ports key_n]
set_false_path -from [get_ports {imu_scl imu_sda key_n}]
