`timescale 1ns/1ps
// UM10204 3.1.16: clear a data-line lock with nine open-drain SCL pulses.
// Other bus clients remain reset until done. A persistent clock/data lock is
// reported, not claimed to be repaired; the normal master then exposes errors.
module i2c_startup_clear #(parameter integer CLK_HZ=50_000_000)(
    input wire clk,rst_n,input wire scl,sda,output wire scl_drive_low,sda_drive_low,
    output reg done,attempted,failed
);
    localparam integer HALF=(CLK_HZ/200000<1)?1:CLK_HZ/200000;
    localparam WAIT=0,CHECK=1,LOW=2,RISE=3,HIGH=4,STOP_LOW=5,STOP_RISE=6,STOP_HIGH=7,RELEASE=8,END=9;
    reg [3:0] state,pulses;
    reg [31:0] delay_count,watchdog;
    reg scl_low,sda_low;
    (* ASYNC_REG="TRUE" *) reg [1:0] cs,ds;
    assign scl_drive_low=scl_low;
    assign sda_drive_low=sda_low;
    always @(posedge clk) begin
        if(!rst_n) begin cs<=3;ds<=3;end
        else begin cs<={cs[0],scl};ds<={ds[0],sda};end
        if(!rst_n) begin
            state<=WAIT;pulses<=0;delay_count<=CLK_HZ/1000;watchdog<=0;
            done<=0;attempted<=0;failed<=0;scl_low<=0;sda_low<=0;
        end else if(!done) begin
            watchdog<=watchdog+1'b1;
            if(watchdog>=CLK_HZ/100) begin done<=1;failed<=1;scl_low<=0;sda_low<=0;end
            else case(state)
                WAIT:if(delay_count!=0) delay_count<=delay_count-1'b1;else state<=CHECK;
                CHECK:if(cs[1]) begin
                    if(ds[1]) begin done<=1;state<=END;end
                    else begin attempted<=1;scl_low<=1;delay_count<=HALF;state<=LOW;end
                end
                LOW:if(delay_count!=0) delay_count<=delay_count-1'b1;
                    else begin scl_low<=0;state<=RISE;end
                RISE:if(cs[1]) begin delay_count<=HALF;state<=HIGH;end
                HIGH:if(delay_count!=0) delay_count<=delay_count-1'b1;
                    else begin
                        scl_low<=1;delay_count<=HALF;
                        if(pulses==8) begin sda_low<=1;state<=STOP_LOW;end
                        else begin pulses<=pulses+1'b1;state<=LOW;end
                    end
                STOP_LOW:if(delay_count!=0) delay_count<=delay_count-1'b1;
                    else begin scl_low<=0;state<=STOP_RISE;end
                STOP_RISE:if(cs[1]) begin delay_count<=HALF;state<=STOP_HIGH;end
                STOP_HIGH:if(delay_count!=0) delay_count<=delay_count-1'b1;
                    else begin sda_low<=0;delay_count<=HALF;state<=RELEASE;end
                RELEASE:if(delay_count!=0) delay_count<=delay_count-1'b1;
                    else begin done<=1;failed<=!cs[1] || !ds[1];state<=END;end
                default:begin done<=1;failed<=1;scl_low<=0;sda_low<=0;end
            endcase
        end
    end
endmodule
