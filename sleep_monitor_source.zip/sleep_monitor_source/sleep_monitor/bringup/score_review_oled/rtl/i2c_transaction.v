`timescale 1ns/1ps
// Single register write or 1..6 byte burst read. Both bus pins are open drain.
// Read bytes are packed in wire order, first byte most significant.
module i2c_transaction #(
    parameter integer CLK_HZ=50_000_000, I2C_HZ=100_000
)(
    input wire clk,input wire rst_n,input wire start,
    input wire [6:0] device_addr,input wire [7:0] register_addr,
    input wire operation_read,input wire [7:0] write_data,input wire [2:0] read_length,
    input wire scl,input wire sda,output wire scl_drive_low,sda_drive_low,
    output reg busy,output reg done,output reg [47:0] read_data,
    output reg [2:0] error_code
);
    localparam integer QDIV=(CLK_HZ+4*I2C_HZ-1)/(4*I2C_HZ);
    localparam [5:0] IDLE=0,BUS_FREE=1,START_HOLD=2,TX_SET=3,TX_RAISE=4,
        TX_WAIT=5,TX_HIGH=6,ACK_SET=7,ACK_RAISE=8,ACK_WAIT=9,ACK_HIGH=10,
        REPEAT_SETUP=11,REPEAT_RAISE=12,REPEAT_WAIT=13,REPEAT_START=14,
        REPEAT_LOW=15,RX_SET=16,RX_RAISE=17,RX_WAIT=18,RX_HIGH=19,
        NACK_SET=20,NACK_RAISE=21,NACK_WAIT=22,NACK_HIGH=23,
        STOP_LOW=24,STOP_RAISE=25,STOP_WAIT=26,STOP_RELEASE=27,FINISH=28;
    reg scl_low,sda_low;
    assign scl_drive_low=scl_low;
    assign sda_drive_low=sda_low;
    (* ASYNC_REG="TRUE" *) reg [1:0] scl_sync,sda_sync;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin scl_sync<=2'b11;sda_sync<=2'b11;end
        else begin scl_sync<={scl_sync[0],scl};sda_sync<={sda_sync[0],sda};end
    end
    reg [31:0] prescaler,watchdog;
    reg [5:0] state;
    reg [1:0] stage;
    reg [2:0] bit_index;
    reg [7:0] tx_byte,rx_byte,saved_register;
    reg [6:0] saved_address;
    reg saved_read;
    reg [7:0] saved_data;
    reg [2:0] remaining;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            scl_low<=0;sda_low<=0;busy<=0;done<=0;read_data<=0;error_code<=0;
            state<=IDLE;prescaler<=0;watchdog<=0;stage<=0;bit_index<=7;
            tx_byte<=0;rx_byte<=0;saved_register<=0;saved_address<=0;saved_read<=0;saved_data<=0;remaining<=1;
        end else begin
            done<=0;
            if(!busy) begin
                prescaler<=0;watchdog<=0;scl_low<=0;sda_low<=0;
                if(start) begin
                    busy<=1;error_code<=0;read_data<=0;state<=BUS_FREE;
                    saved_address<=device_addr;saved_register<=register_addr;
                    saved_read<=operation_read;saved_data<=write_data;remaining<=read_length;
                    tx_byte<={device_addr,1'b0};stage<=0;bit_index<=7;rx_byte<=0;
                    if(operation_read && (read_length==0 || read_length>6)) begin
                        busy<=0;done<=1;error_code<=6;state<=IDLE;
                    end
                end
            end else if(watchdog>=CLK_HZ/100-1) begin
                // 10 ms bound also covers an idle bus stuck low or stretched clock.
                busy<=0;done<=1;error_code<=4;state<=IDLE;scl_low<=0;sda_low<=0;
            end else begin
                watchdog<=watchdog+1'b1;
                if(prescaler<QDIV-1) prescaler<=prescaler+1'b1;
                else begin
                    prescaler<=0;
                    case(state)
                        BUS_FREE: if(scl_sync[1] && sda_sync[1]) begin sda_low<=1;state<=START_HOLD;end
                        START_HOLD: begin scl_low<=1;state<=TX_SET;end
                        TX_SET: begin sda_low<=!tx_byte[bit_index];state<=TX_RAISE;end
                        TX_RAISE: begin scl_low<=0;state<=TX_WAIT;end
                        TX_WAIT: if(scl_sync[1]) state<=TX_HIGH;
                        TX_HIGH: begin
                            scl_low<=1;
                            if(bit_index==0) state<=ACK_SET;
                            else begin bit_index<=bit_index-1'b1;state<=TX_SET;end
                        end
                        ACK_SET: begin sda_low<=0;state<=ACK_RAISE;end
                        ACK_RAISE: begin scl_low<=0;state<=ACK_WAIT;end
                        ACK_WAIT: if(scl_sync[1]) state<=ACK_HIGH;
                        ACK_HIGH: begin
                            scl_low<=1;
                            if(sda_sync[1]) begin error_code<=(stage==3)?3'd5:({1'b0,stage}+3'd1);state<=STOP_LOW;end
                            else if(stage==0) begin stage<=1;tx_byte<=saved_register;bit_index<=7;state<=TX_SET;end
                            else if(stage==1) begin
                                if(saved_read) state<=REPEAT_SETUP;
                                else begin stage<=3;tx_byte<=saved_data;bit_index<=7;state<=TX_SET;end
                            end
                            else if(stage==3) state<=STOP_LOW;
                            else begin bit_index<=7;rx_byte<=0;state<=RX_SET;end
                        end
                        REPEAT_SETUP: begin sda_low<=0;state<=REPEAT_RAISE;end
                        REPEAT_RAISE: begin scl_low<=0;state<=REPEAT_WAIT;end
                        REPEAT_WAIT: if(scl_sync[1]) state<=REPEAT_START;
                        REPEAT_START: begin sda_low<=1;state<=REPEAT_LOW;end
                        REPEAT_LOW: begin
                            scl_low<=1;stage<=2;tx_byte<={saved_address,1'b1};bit_index<=7;state<=TX_SET;
                        end
                        RX_SET: begin sda_low<=0;state<=RX_RAISE;end
                        RX_RAISE: begin scl_low<=0;state<=RX_WAIT;end
                        RX_WAIT: if(scl_sync[1]) state<=RX_HIGH;
                        RX_HIGH: begin
                            rx_byte<={rx_byte[6:0],sda_sync[1]};scl_low<=1;
                            if(bit_index==0) begin read_data<={read_data[39:0],rx_byte[6:0],sda_sync[1]};state<=NACK_SET;end
                            else begin bit_index<=bit_index-1'b1;state<=RX_SET;end
                        end
                        NACK_SET: begin sda_low<=(remaining>1);state<=NACK_RAISE;end
                        NACK_RAISE: begin scl_low<=0;state<=NACK_WAIT;end
                        NACK_WAIT: if(scl_sync[1]) state<=NACK_HIGH;
                        NACK_HIGH: begin
                            scl_low<=1;
                            if(remaining>1) begin remaining<=remaining-1'b1;bit_index<=7;rx_byte<=0;state<=RX_SET;end
                            else state<=STOP_LOW;
                        end
                        STOP_LOW: begin sda_low<=1;state<=STOP_RAISE;end
                        STOP_RAISE: begin scl_low<=0;state<=STOP_WAIT;end
                        STOP_WAIT: if(scl_sync[1]) state<=STOP_RELEASE;
                        STOP_RELEASE: begin sda_low<=0;state<=FINISH;end
                        FINISH: begin busy<=0;done<=1;state<=IDLE;end
                        default: begin busy<=0;done<=1;error_code<=4;scl_low<=0;sda_low<=0;state<=IDLE;end
                    endcase
                end
            end
        end
    end
endmodule
