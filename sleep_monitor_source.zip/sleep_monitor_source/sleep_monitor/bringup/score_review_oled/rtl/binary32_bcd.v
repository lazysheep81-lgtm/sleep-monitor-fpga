`timescale 1ns/1ps
module binary32_bcd(input wire clk,input wire [31:0] value,output reg [39:0] decimal=0);
    reg [31:0] binary=0;
    reg [39:0] bcd=0,adjusted;
    reg [5:0] step=0;
    integer i;
    always @*begin
        adjusted=bcd;
        for(i=0;i<10;i=i+1)if(bcd[i*4+:4]>=5)adjusted[i*4+:4]=bcd[i*4+:4]+3;
    end
    always @(posedge clk)begin
        if(step==0)begin binary<=value;bcd<=0;step<=1;end
        else begin
            bcd<={adjusted[38:0],binary[31]};binary<={binary[30:0],1'b0};
            if(step==32)begin decimal<={adjusted[38:0],binary[31]};step<=0;end
            else step<=step+1'b1;
        end
    end
endmodule
