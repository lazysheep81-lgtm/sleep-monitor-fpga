`timescale 1ns/1ps
// Refreshes a snapshot while the shared arbiter services sensor transactions.
module oled_live_client #(parameter integer CLK_HZ=50_000_000)(
    input wire clk,input wire rst_n,
    input wire sensor_ok,input wire fresh,input wire [3:0] sensor_error,
    input wire [17:0] red,ir,input wire [31:0] sequence_number,
    input wire [7:0] bpm,input wire bpm_valid,
    input wire [23:0] mic_mean,input wire mic_live,
    input wire [23:0] event_count,event_centiseconds,
    input wire event_active,event_live,event_fault,
    input wire [23:0] motion_count,input wire motion_live,
    input wire [1:0] research_status,
    input wire [1:0] review_status,
    input wire history_mode,history_loaded,input wire [287:0] history_payload,
    output reg start,output reg [7:0] control,payload,
    input wire done,input wire [2:0] bus_error,
    output reg ready,output reg [6:0] address,output reg [2:0] error
);
    localparam BOOT=0,INIT_REQ=1,INIT_WAIT=2,PAGE_REQ=3,PAGE_WAIT=4,
        ROM_ADDR=5,ROM_WAIT=6,DATA_REQ=7,DATA_WAIT=8,ON_REQ=9,ON_WAIT=10,
        RUN=11,SNAPSHOT=12,RETRY=14;
    reg [3:0] state;
    reg [31:0] delay_count;
    reg [4:0] init_index;
    reg [1:0] page_command;
    reg [2:0] page;
    reg [6:0] column;
    reg [9:0] rom_address;
    wire [7:0] rom_data,live_rom_data,history_rom_data;
    reg snap_history_mode,snap_history_loaded;reg [287:0] snap_history_payload;
    assign rom_data=snap_history_mode?history_rom_data:live_rom_data;
    history_screen_rom history_frame(clk,rom_address,snap_history_loaded,snap_history_payload,history_rom_data);
    reg [1:0] snap_research,snap_review;
    reg snap_ok,snap_fresh,snap_bpm_valid;
    reg [7:0] snap_bpm;
    reg [23:0] snap_mic;reg snap_mic_live;
    reg [23:0] snap_event_count,snap_event_cs;
    reg snap_event_active,snap_event_live,snap_event_fault;
    reg [23:0] snap_motion_count;reg snap_motion_live;
    reg [3:0] snap_error;
    reg [17:0] snap_red,snap_ir;
    reg [31:0] snap_sequence;
    // All values are latched together, so a slow frame cannot mix samples.
    // Font ROM address bits must be driven by synchronously reset registers.
    always @(posedge clk) begin
        if(!rst_n) begin
            snap_history_mode<=0;snap_history_loaded<=0;snap_history_payload<=0;
            snap_motion_count<=0;snap_motion_live<=0;
            snap_research<=0;snap_review<=0;snap_ok<=0;snap_fresh<=0;snap_error<=0;snap_bpm<=0;snap_bpm_valid<=0;
            snap_red<=0;snap_ir<=0;snap_sequence<=0;snap_mic<=0;snap_mic_live<=0;
            snap_event_count<=0;snap_event_cs<=0;snap_event_active<=0;snap_event_live<=0;snap_event_fault<=0;
        end else if(state==SNAPSHOT) begin
            snap_history_mode<=history_mode;snap_history_loaded<=history_loaded;snap_history_payload<=history_payload;
            snap_motion_count<=motion_count;snap_motion_live<=motion_live;
            snap_research<=research_status;snap_review<=review_status;snap_ok<=sensor_ok;snap_fresh<=fresh;snap_error<=sensor_error;
            snap_bpm<=bpm;snap_bpm_valid<=bpm_valid && fresh;
            snap_red<=red;snap_ir<=ir;snap_sequence<=sequence_number;
            snap_mic<=mic_mean;snap_mic_live<=mic_live;
            snap_event_count<=event_count;snap_event_cs<=event_centiseconds;
            snap_event_active<=event_active;snap_event_live<=event_live;snap_event_fault<=event_fault;
        end
    end
    ppg_screen_rom frame(clk,rom_address,snap_ok,snap_fresh,snap_error,
        snap_red,snap_ir,snap_sequence,snap_bpm,snap_bpm_valid,snap_mic,snap_mic_live,
        snap_event_count,snap_event_cs,snap_event_active,snap_event_live,snap_event_fault,snap_motion_count,snap_motion_live,snap_research,snap_review,live_rom_data);
    // Keep RAM address controls synchronous; an asynchronous reset on an address
    // register can violate the BRAM's control timing during reset assertion.
    always @(posedge clk) begin
        if(!rst_n) rom_address<=0;
        else if(state==ROM_ADDR) rom_address<={page,column};
    end
    function [7:0] init_command;
        input [4:0] index;
        begin
            case(index)
                0:init_command=8'hae; 1:init_command=8'hd5; 2:init_command=8'h80;
                3:init_command=8'ha8; 4:init_command=8'h3f; 5:init_command=8'hd3;
                6:init_command=8'h00; 7:init_command=8'h40; 8:init_command=8'h8d;
                9:init_command=8'h14; 10:init_command=8'h20;11:init_command=8'h02;
                12:init_command=8'ha1;13:init_command=8'hc8;14:init_command=8'hda;
                15:init_command=8'h12;16:init_command=8'h81;17:init_command=8'h7f;
                18:init_command=8'hd9;19:init_command=8'hf1;20:init_command=8'hdb;
                21:init_command=8'h40;22:init_command=8'ha4;23:init_command=8'ha6;
                default:init_command=8'h2e; // scroll off
            endcase
        end
    endfunction
    task launch;
        input [7:0] ctl,value;
        input [3:0] next_state;
        begin control<=ctl;payload<=value;start<=1;state<=next_state;end
    endtask
    task fail;
        begin ready<=0;error<=bus_error;delay_count<=CLK_HZ-1;state<=RETRY;end
    endtask
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            ready<=0;address<=7'h3c;error<=0;state<=BOOT;delay_count<=CLK_HZ/10-1;
            init_index<=0;page_command<=0;page<=0;column<=0;
            start<=0;control<=0;payload<=0;
        end else begin
            start<=0;
            case(state)
                BOOT,RETRY: if(delay_count!=0) delay_count<=delay_count-1'b1;
                    else begin address<=7'h3c;init_index<=0;state<=INIT_REQ;end
                INIT_REQ: launch(0,init_command(init_index),INIT_WAIT);
                INIT_WAIT: if(done) begin
                    if(bus_error!=0) begin
                        if(init_index==0 && address==7'h3c && bus_error==1) begin address<=7'h3d;state<=INIT_REQ;end
                        else fail;
                    end else begin
                        error<=0;
                        if(init_index==24) begin page<=0;page_command<=0;column<=0;state<=SNAPSHOT;end
                        else begin init_index<=init_index+1'b1;state<=INIT_REQ;end
                    end
                end
                PAGE_REQ: case(page_command)
                    0:launch(0,{5'b10110,page},PAGE_WAIT);
                    1:launch(0,8'h00,PAGE_WAIT);
                    default:launch(0,8'h10,PAGE_WAIT);
                endcase
                PAGE_WAIT: if(done) begin
                    if(bus_error!=0) fail;
                    else if(page_command==2) state<=ROM_ADDR;
                    else begin page_command<=page_command+1'b1;state<=PAGE_REQ;end
                end
                ROM_ADDR: state<=ROM_WAIT;
                ROM_WAIT: state<=DATA_REQ;
                DATA_REQ: launch(8'h40,rom_data,DATA_WAIT);
                DATA_WAIT: if(done) begin
                    if(bus_error!=0) fail;
                    else if(column==127) begin
                        column<=0;
                        if(page==7) state<=ON_REQ;
                        else begin page<=page+1'b1;page_command<=0;state<=PAGE_REQ;end
                    end else begin column<=column+1'b1;state<=ROM_ADDR;end
                end
                ON_REQ: launch(0,8'haf,ON_WAIT);
                ON_WAIT: if(done) begin
                    if(bus_error!=0) fail;
                    else begin ready<=1;error<=0;delay_count<=CLK_HZ-1;state<=RUN;end
                end
                RUN: if(delay_count!=0) delay_count<=delay_count-1'b1;
                    else begin page<=0;column<=0;page_command<=0;state<=SNAPSHOT;end
                SNAPSHOT: state<=PAGE_REQ;
                default: begin ready<=0;error<=4;delay_count<=CLK_HZ-1;state<=RETRY;end
            endcase
        end
    end
endmodule
