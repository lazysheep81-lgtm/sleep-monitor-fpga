`timescale 1ns/1ps
module standalone_core #(parameter integer CLK_HZ=50_000_000,BAUD=1_000_000,
    MIC_HALF_PERIOD=25,MIC_WARMUP_FRAMES=8192,MIC_WINDOW_LOG2=10)(
    (* X_INTERFACE_INFO="xilinx.com:signal:clock:1.0 sys_clk CLK", X_INTERFACE_PARAMETER="ASSOCIATED_BUSIF s_axi, ASSOCIATED_RESET sys_rst_n, FREQ_HZ 50000000" *)
    input wire sys_clk,
    (* X_INTERFACE_INFO="xilinx.com:signal:reset:1.0 sys_rst_n RST", X_INTERFACE_PARAMETER="POLARITY ACTIVE_LOW" *)
    input wire sys_rst_n,
    inout wire shared_scl,inout wire shared_sda,
    input wire mic_sd,output wire mic_sck,mic_ws,
    output wire uart_txd,output wire [1:0] led,
    inout wire imu_scl,imu_sda,input wire key_n,output wire ext_beep,
    (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi AWADDR" *)
    input wire [17:0] s_axi_awaddr, (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi AWPROT" *)
    input wire [2:0] s_axi_awprot,
    (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi AWVALID" *)
    input wire s_axi_awvalid, (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi AWREADY" *)
    output wire s_axi_awready,
    (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi WDATA" *)
    input wire [31:0] s_axi_wdata, (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi WSTRB" *)
    input wire [3:0] s_axi_wstrb,
    (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi WVALID" *)
    input wire s_axi_wvalid, (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi WREADY" *)
    output wire s_axi_wready,
    (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi BRESP" *)
    output wire [1:0] s_axi_bresp, (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi BVALID" *)
    output wire s_axi_bvalid, (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi BREADY" *)
    input wire s_axi_bready,
    (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi ARADDR" *)
    input wire [17:0] s_axi_araddr, (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi ARPROT" *)
    input wire [2:0] s_axi_arprot,
    (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi ARVALID" *)
    input wire s_axi_arvalid, (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi ARREADY" *)
    output wire s_axi_arready,
    (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi RDATA" *)
    output wire [31:0] s_axi_rdata, (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi RRESP" *)
    output wire [1:0] s_axi_rresp,
    (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi RVALID" *)
    output wire s_axi_rvalid, (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 s_axi RREADY" *)
    input wire s_axi_rready
);
    reg [15:0] por=0;
    always @(posedge sys_clk or negedge sys_rst_n)
        if(!sys_rst_n) por<=0;else if(!por[15]) por<=por+1'b1;
    wire reset_request_n=sys_rst_n && por[15];
    (* ASYNC_REG="TRUE" *) reg [1:0] reset_sync;
    always @(posedge sys_clk or negedge reset_request_n)
        if(!reset_request_n) reset_sync<=0;else reset_sync<={reset_sync[0],1'b1};
    wire rst_n=reset_sync[1];
    wire motion_live,motion_active;wire [23:0] motion_count;
    wire scl_in,sda_in,clear_scl_low,clear_sda_low,bus_scl_low,bus_sda_low;
    wire imu_scl_in,imu_sda_in,imu_clear_scl_low,imu_clear_sda_low,imu_bus_scl_low,imu_bus_sda_low;
    IOBUF imu_scl_buffer(.IO(imu_scl),.I(1'b0),.O(imu_scl_in),.T(!(imu_clear_scl_low || imu_bus_scl_low)));
    IOBUF imu_sda_buffer(.IO(imu_sda),.I(1'b0),.O(imu_sda_in),.T(!(imu_clear_sda_low || imu_bus_sda_low)));
    IOBUF scl_buffer(.IO(shared_scl),.I(1'b0),.O(scl_in),.T(!(clear_scl_low || bus_scl_low)));
    IOBUF sda_buffer(.IO(shared_sda),.I(1'b0),.O(sda_in),.T(!(clear_sda_low || bus_sda_low)));
    wire configured,sample_valid,status_valid;
    wire [17:0] red,ir;
    wire [31:0] sequence_number;
    wire [3:0] status_error;
    wire [7:0] status_register,status_value;
    wire status_ready,mic_ready,sample_ready;
    wire bus_clear_done,bus_clear_attempted,bus_clear_failed;
    i2c_startup_clear #(.CLK_HZ(CLK_HZ)) startup_clear(
        sys_clk,rst_n,scl_in,sda_in,clear_scl_low,clear_sda_low,bus_clear_done,bus_clear_attempted,bus_clear_failed);
    wire bus_rst_n=rst_n && bus_clear_done;
    wire sensor_start,sensor_read,sensor_done;
    wire [7:0] sensor_register,sensor_write;
    wire [2:0] sensor_length,sensor_bus_error;
    wire [47:0] sensor_bus_data;
    wire oled_start,oled_done,oled_ready;
    wire [7:0] oled_control,oled_payload;
    wire [6:0] oled_address;
    wire [2:0] oled_error,oled_bus_error;
    ppg_acquisition_client #(.CLK_HZ(CLK_HZ)) acquisition(
        sys_clk,bus_rst_n,sensor_start,sensor_read,sensor_register,sensor_write,sensor_length,
        sensor_done,sensor_bus_data,sensor_bus_error,configured,
        sample_valid,sample_ready,red,ir,sequence_number,
        status_valid,status_ready,status_error,status_register,status_value
    );
    wire signed [23:0] mic_sample,mic_minimum,mic_maximum;
    wire mic_sample_valid,mic_valid,mic_live;
    wire [31:0] mic_sequence;
    wire [23:0] mic_mean;
    wire [10:0] mic_zeros,mic_clipped;
    wire [15:0] mic_skipped;
    i2s_microphone #(.HALF_PERIOD(MIC_HALF_PERIOD),.WARMUP_FRAMES(MIC_WARMUP_FRAMES)) microphone(
        sys_clk,rst_n,mic_sd,mic_sck,mic_ws,mic_sample,mic_sample_valid);
    microphone_statistics #(.WINDOW_LOG2(MIC_WINDOW_LOG2)) statistics(
        sys_clk,rst_n,mic_sample_valid,mic_sample,mic_ready,
        mic_valid,mic_sequence,mic_minimum,mic_maximum,mic_mean,
        mic_zeros,mic_clipped,mic_skipped,mic_live);
    reg [31:0] sample_age;
    reg have_sample;
    wire fresh=configured && have_sample && sample_age<CLK_HZ;
    always @(posedge sys_clk or negedge rst_n) begin
        if(!rst_n) begin sample_age<=CLK_HZ;have_sample<=0;end
        else if(!configured) begin sample_age<=CLK_HZ;have_sample<=0;end
        else if(sample_valid && sample_ready) begin sample_age<=0;have_sample<=1;end
        else if(sample_age<CLK_HZ) sample_age<=sample_age+1'b1;
    end
    wire [7:0] pulse_bpm;
    wire pulse_valid,pulse_done,pulse_busy;
    wire [11:0] pulse_candidate;
    pulse_window #(.CLK_HZ(CLK_HZ)) estimator(sys_clk,rst_n,configured,
        sample_valid && sample_ready,red,ir,sequence_number,
        pulse_bpm,pulse_valid,pulse_done,pulse_candidate,pulse_busy);
    wire [1:0] research_status,review_status;
    wire history_mode,history_loaded;wire [31:0] history_request,history_offset;wire [287:0] history_payload;
    wire event_active,event_live,event_fault;
    wire [23:0] event_count,event_complete_count,event_centiseconds;
    wire [159:0] telemetry_live={{event_live,7'd0,event_centiseconds},{event_live,7'd0,event_count},
       {mic_live,7'd0,mic_mean},{23'd0,(pulse_valid && fresh),pulse_bpm},{motion_live,7'd0,motion_count}};
    snore_axi_ring #(.CLK_HZ(CLK_HZ),.SAMPLE_RATE(CLK_HZ/(128*MIC_HALF_PERIOD))) ring(
        .clk(sys_clk),.rst_n(rst_n),.sample_valid(mic_sample_valid),.sample(mic_sample),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_awready(s_axi_awready),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wvalid(s_axi_wvalid),
        .s_axi_wready(s_axi_wready),
        .s_axi_bresp(s_axi_bresp),
        .s_axi_bvalid(s_axi_bvalid),
        .s_axi_bready(s_axi_bready),
        .s_axi_araddr(s_axi_araddr),
        .s_axi_arprot(s_axi_arprot),
        .s_axi_arvalid(s_axi_arvalid),
        .s_axi_arready(s_axi_arready),
        .s_axi_rdata(s_axi_rdata),
        .s_axi_rresp(s_axi_rresp),
        .s_axi_rvalid(s_axi_rvalid),
        .s_axi_rready(s_axi_rready),
        .research_status(research_status),.review_status(review_status),
        .telemetry_live(telemetry_live),.history_mode(history_mode),.history_request(history_request),
        .history_offset(history_offset),.history_payload(history_payload),.history_loaded(history_loaded));
    wire [31:0] event_duration,event_total_samples;
    sound_event_detector #(.CLK_HZ(CLK_HZ)) sound_events(
        sys_clk,rst_n,mic_sample_valid,mic_sample,event_active,event_live,event_fault,
        event_count,event_complete_count,event_duration,event_total_samples);
    samples_to_centiseconds #(.SAMPLE_RATE(CLK_HZ/(128*MIC_HALF_PERIOD))) event_time(
        sys_clk,rst_n,event_duration,event_centiseconds);
    oled_live_client #(.CLK_HZ(CLK_HZ)) display(
        sys_clk,bus_rst_n,configured,fresh,status_error,red,ir,sequence_number,pulse_bpm,pulse_valid,mic_mean,mic_live,
        event_count,event_centiseconds,event_active,event_live,event_fault,motion_count,motion_live,
        research_status,review_status,history_mode,history_loaded,history_payload,oled_start,oled_control,oled_payload,oled_done,oled_bus_error,
        oled_ready,oled_address,oled_error
    );
    shared_i2c_bus #(.CLK_HZ(CLK_HZ)) bus(
        sys_clk,bus_rst_n,scl_in,sda_in,bus_scl_low,bus_sda_low,
        sensor_start,sensor_read,sensor_register,sensor_write,sensor_length,
        sensor_done,sensor_bus_data,sensor_bus_error,
        oled_start,oled_address,oled_control,oled_payload,oled_done,oled_bus_error
    );
    wire [31:0] audio_dropped;
    audio_transport #(.CLK_HZ(CLK_HZ),.BAUD(BAUD),.SAMPLE_RATE(CLK_HZ/(128*MIC_HALF_PERIOD))) transport(
        sys_clk,rst_n,mic_sample_valid,mic_sample,
        sample_valid,sample_ready,sequence_number,red,ir,
        status_valid,status_ready,status_error,status_register,status_value,
        mic_valid,mic_ready,mic_sequence,mic_minimum,mic_maximum,mic_mean,
        mic_zeros,mic_clipped,mic_skipped,pulse_bpm,pulse_valid,
        {bus_clear_failed,bus_clear_attempted},
        event_count,event_complete_count,event_duration,event_total_samples,
        {event_fault,event_live,event_active},uart_txd,audio_dropped);
    wire imu_clear_done,imu_clear_attempted,imu_clear_failed;
    i2c_startup_clear #(.CLK_HZ(CLK_HZ)) imu_clear(sys_clk,rst_n,imu_scl_in,imu_sda_in,imu_clear_scl_low,imu_clear_sda_low,
        imu_clear_done,imu_clear_attempted,imu_clear_failed);
    wire imu_rst_n=rst_n && imu_clear_done;
    wire imu_start,imu_read,imu_done,imu_busy,imu_configured,imu_valid;
    wire [6:0] imu_address;wire [7:0] imu_register,imu_write;
    wire [2:0] imu_length,imu_error;wire [47:0] imu_data;
    wire [3:0] imu_status;
    wire signed [15:0] ax,ay,az,gx,gy,gz;
    mpu6050_client #(.CLK_HZ(CLK_HZ)) imu_client(sys_clk,imu_rst_n,
        imu_start,imu_read,imu_address,imu_register,imu_write,imu_length,
        imu_done,imu_data,imu_error,imu_configured,imu_valid,motion_live,
        ax,ay,az,gx,gy,gz,imu_status);
    i2c_transaction #(.CLK_HZ(CLK_HZ)) imu_engine(sys_clk,imu_rst_n,imu_start,
        imu_address,imu_register,imu_read,imu_write,imu_length,
        imu_scl_in,imu_sda_in,imu_bus_scl_low,imu_bus_sda_low,imu_busy,imu_done,imu_data,imu_error);
    motion_counter movement(sys_clk,rst_n,motion_live,imu_valid,ax,ay,az,motion_active,motion_count);
    history_key #(.CLK_HZ(CLK_HZ)) history_control(sys_clk,rst_n,key_n,ext_beep,history_mode,history_request,history_offset);
    reg [31:0] heartbeat;
    reg activity;
    always @(posedge sys_clk or negedge rst_n) begin
        if(!rst_n) begin heartbeat<=0;activity<=0;end
        else if(heartbeat==CLK_HZ/2-1) begin heartbeat<=0;activity<=!activity;end
        else heartbeat<=heartbeat+1'b1;
    end
    assign led={configured && oled_ready,activity};
endmodule
