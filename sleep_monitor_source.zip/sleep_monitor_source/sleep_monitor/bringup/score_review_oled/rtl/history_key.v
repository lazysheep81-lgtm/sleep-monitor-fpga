`timescale 1ns/1ps
// One existing key; no rewiring. Long presses never sound the test buzzer.
module history_key #(parameter integer CLK_HZ=50000000)(
    input wire clk,rst_n,key_n,output wire beep,
    output reg history_mode,output reg [31:0] request_tag,history_offset
);
    localparam integer DEBOUNCE=(CLK_HZ/50<1)?1:CLK_HZ/50;
    localparam integer HOLD=CLK_HZ+CLK_HZ/5;
    (* ASYNC_REG="TRUE" *) reg [1:0] sync_key;
    reg stable,armed,press,long_fired;
    reg [31:0] debounce,held,pulse_left;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            sync_key<=0;stable<=0;armed<=0;press<=0;long_fired<=0;
            debounce<=0;held<=0;pulse_left<=0;history_mode<=0;request_tag<=0;history_offset<=0;
        end else begin
            sync_key<={sync_key[0],key_n};
            if(pulse_left!=0)pulse_left<=pulse_left-1'b1;
            if(press && !stable && !long_fired) begin
                if(held>=HOLD-1) begin
                    long_fired<=1;history_mode<=!history_mode;
                    if(!history_mode)begin history_offset<=0;request_tag<=request_tag+1'b1;end
                end else held<=held+1'b1;
            end
            if(sync_key[1]==stable)debounce<=0;
            else if(debounce>=DEBOUNCE-1) begin
                stable<=sync_key[1];debounce<=0;
                if(sync_key[1])begin
                    if(press && !long_fired)begin
                        if(history_mode)begin history_offset<=history_offset+1'b1;request_tag<=request_tag+1'b1;end
                        else pulse_left<=CLK_HZ/10;
                    end
                    armed<=1;press<=0;long_fired<=0;held<=0;
                end else if(armed)begin press<=1;armed<=0;held<=0;long_fired<=0;end
            end else debounce<=debounce+1'b1;
        end
    end
    assign beep=rst_n && pulse_left!=0;
endmodule
