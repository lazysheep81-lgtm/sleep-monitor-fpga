`timescale 1ns/1ps
// One physical master. Each client may have one outstanding transaction.
// Arbitration is per transaction, including every repeated START and STOP.
module shared_i2c_bus #(parameter integer CLK_HZ=50_000_000)(
    input wire clk,input wire rst_n,input wire scl,input wire sda,output wire scl_drive_low,sda_drive_low,
    input wire a_start,input wire a_read,input wire [7:0] a_register,a_write,
    input wire [2:0] a_length,
    output reg a_done,output reg [47:0] a_data,output reg [2:0] a_error,
    input wire b_start,input wire [6:0] b_address,
    input wire [7:0] b_control,b_payload,
    output reg b_done,output reg [2:0] b_error
);
    reg pending_a,pending_b;
    reg saved_read;
    reg [7:0] saved_register,saved_write,saved_control,saved_payload;
    reg [2:0] saved_length;
    reg [6:0] saved_address;
    reg active,owner,last_owner,start;
    reg [6:0] address;
    reg [7:0] register_address,write_data;
    reg reading;
    reg [2:0] length;
    wire busy,done;
    wire [47:0] read_data;
    wire [2:0] error;
    i2c_transaction #(.CLK_HZ(CLK_HZ)) engine(
        clk,rst_n,start,address,register_address,reading,write_data,length,
        scl,sda,scl_drive_low,sda_drive_low,busy,done,read_data,error
    );
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            pending_a<=0;pending_b<=0;saved_read<=0;saved_register<=0;saved_write<=0;
            saved_control<=0;saved_payload<=0;saved_length<=1;saved_address<=0;
            active<=0;owner<=0;last_owner<=1;start<=0;address<=0;
            register_address<=0;write_data<=0;reading<=0;length<=1;
            a_done<=0;a_data<=0;a_error<=0;b_done<=0;b_error<=0;
        end else begin
            start<=0;a_done<=0;b_done<=0;
            if(a_start) begin
                pending_a<=1;saved_read<=a_read;saved_register<=a_register;
                saved_write<=a_write;saved_length<=a_length;
            end
            if(b_start) begin
                pending_b<=1;saved_address<=b_address;
                saved_control<=b_control;saved_payload<=b_payload;
            end
            if(active) begin
                if(done) begin
                    active<=0;last_owner<=owner;
                    if(owner) begin b_done<=1;b_error<=error;end
                    else begin a_done<=1;a_data<=read_data;a_error<=error;end
                end
            end else if(!busy && !start) begin
                if(pending_a && (!pending_b || last_owner)) begin
                    owner<=0;active<=1;pending_a<=0;start<=1;
                    address<=7'h57;register_address<=saved_register;
                    write_data<=saved_write;reading<=saved_read;length<=saved_length;
                end else if(pending_b) begin
                    owner<=1;active<=1;pending_b<=0;start<=1;
                    address<=saved_address;register_address<=saved_control;
                    write_data<=saved_payload;reading<=0;length<=1;
                end
            end
        end
    end
endmodule
