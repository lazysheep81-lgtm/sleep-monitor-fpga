`timescale 1ns/1ps
// AXI4-Lite audio ring and atomic ARM -> OLED research-result mailbox.
// One clock domain. Audio cannot be stalled by Linux or AXI backpressure.
module snore_axi_ring #(
    parameter integer CLK_HZ=50000000, SAMPLE_RATE=15625, RING_LOG2=15
)(
    input wire clk, input wire rst_n,
    input wire sample_valid, input wire signed [23:0] sample,
    input wire [17:0] s_axi_awaddr, input wire [2:0] s_axi_awprot,
    input wire s_axi_awvalid, output wire s_axi_awready,
    input wire [31:0] s_axi_wdata, input wire [3:0] s_axi_wstrb,
    input wire s_axi_wvalid, output wire s_axi_wready,
    output reg [1:0] s_axi_bresp, output reg s_axi_bvalid, input wire s_axi_bready,
    input wire [17:0] s_axi_araddr, input wire [2:0] s_axi_arprot,
    input wire s_axi_arvalid, output wire s_axi_arready,
    output reg [31:0] s_axi_rdata, output reg [1:0] s_axi_rresp,
    output reg s_axi_rvalid, input wire s_axi_rready,
    output wire [1:0] research_status, output wire [1:0] review_status,
    input wire [159:0] telemetry_live,
    input wire history_mode,input wire [31:0] history_request,history_offset,
    output reg [287:0] history_payload,output wire history_loaded
);
    localparam integer DEPTH=1<<RING_LOG2, TTL=CLK_HZ+CLK_HZ/2;
    (* ram_style="block" *) reg [31:0] audio_ram [0:DEPTH-1];
    reg [159:0] telemetry_snapshot;
    reg [31:0] history_stage[0:8];reg [8:0] history_written;
    reg history_seen;reg [31:0] history_rejected;integer h;
    assign history_loaded=history_mode && history_seen && history_payload[31:0]==history_request;
    reg [31:0] produced, sample_age, result_age, result_end, rejected_commits;
    reg [1:0] result_code,result_review;
    reg result_seen;
    reg [31:0] staged_end, staged_code,staged_review;
    reg end_written,code_written,review_written;
    reg aw_pending,w_pending;
    reg [17:0] aw_address;
    reg [31:0] w_data;
    reg [3:0] w_strobe;
    reg read_pending,read_ram;
    reg [31:0] read_register,read_ram_data;
    reg ram_write_enable;
    reg signed [23:0] ram_write_sample;
    reg [1:0] read_response;
    wire [31:0] staged_lag=produced-staged_end;
    wire [31:0] staged_advance=staged_end-result_end;
    wire [31:0] result_lag=produced-result_end;
    wire fresh_audio=sample_age<CLK_HZ/2;
    wire result_fresh=result_seen && fresh_audio && result_age<TTL &&
                            result_lag<=SAMPLE_RATE+SAMPLE_RATE/2;
    assign research_status=result_fresh?result_code:2'd0;
    assign review_status=result_fresh?result_review:2'd0;
    assign s_axi_awready=!aw_pending && !s_axi_bvalid;
    assign s_axi_wready=!w_pending && !s_axi_bvalid;
    assign s_axi_arready=!read_pending && !s_axi_rvalid;

    // Synchronous BRAM ports; reset never reaches memory address/data registers.
    always @(posedge clk) begin
        if(!rst_n) ram_write_enable<=0;else ram_write_enable<=sample_valid;
        ram_write_sample<=sample;
        if(ram_write_enable)
            audio_ram[produced[RING_LOG2-1:0]]<={{8{ram_write_sample[23]}},ram_write_sample};
        if(s_axi_arvalid && s_axi_arready)
            read_ram_data<=audio_ram[s_axi_araddr[RING_LOG2+1:2]];
    end
    always @(posedge clk) begin
        if(!rst_n) begin
            produced<=0;sample_age<=CLK_HZ;result_age<=TTL;
            telemetry_snapshot<=0;history_payload<=0;history_seen<=0;history_written<=0;history_rejected<=0;
            for(h=0;h<9;h=h+1)history_stage[h]<=0;
            result_end<=0;result_code<=0;result_review<=0;result_seen<=0;rejected_commits<=0;
            staged_end<=0;staged_code<=0;staged_review<=0;end_written<=0;code_written<=0;review_written<=0;
            aw_pending<=0;w_pending<=0;aw_address<=0;w_data<=0;w_strobe<=0;
            s_axi_bvalid<=0;s_axi_bresp<=0;
            read_pending<=0;read_ram<=0;read_register<=0;read_response<=0;
            s_axi_rvalid<=0;s_axi_rdata<=0;s_axi_rresp<=0;
        end else begin
            if(ram_write_enable) begin produced<=produced+1'b1;sample_age<=0;end
            else if(sample_age<CLK_HZ) sample_age<=sample_age+1'b1;
            if(result_age<TTL) result_age<=result_age+1'b1;
            if(s_axi_awvalid && s_axi_awready) begin aw_pending<=1;aw_address<=s_axi_awaddr;end
            if(s_axi_wvalid && s_axi_wready) begin
                w_pending<=1;w_data<=s_axi_wdata;w_strobe<=s_axi_wstrb;
            end
            if(s_axi_bvalid && s_axi_bready) s_axi_bvalid<=0;
            if(aw_pending && w_pending && !s_axi_bvalid) begin
                aw_pending<=0;w_pending<=0;s_axi_bvalid<=1;s_axi_bresp<=0;
                if(w_strobe!=4'hf || aw_address[1:0]!=0) s_axi_bresp<=2;
                else if(aw_address>=18'h80 && aw_address<=18'ha0)begin
                    history_stage[(aw_address-18'h80)>>2]<=w_data;history_written[(aw_address-18'h80)>>2]<=1;
                end else case(aw_address)
                    18'h00040:begin staged_end<=w_data;end_written<=1;end
                    18'h00044:begin staged_code<=w_data;code_written<=1;end
                    18'h00054:begin staged_review<=w_data;review_written<=1;end
                    18'h00048:begin
                        end_written<=0;code_written<=0;review_written<=0;
                        if(w_data==32'h534e5231 && end_written && code_written && review_written &&
                           staged_review<=3 && (staged_code!=0 || staged_review==0 || staged_review==2) &&
                           (staged_code!=3 || staged_review==2) &&
                           staged_code<=3 && staged_lag<=SAMPLE_RATE+SAMPLE_RATE/2 &&
                           (!result_seen || (staged_advance!=0 && !staged_advance[31])) && fresh_audio) begin
                            result_end<=staged_end;result_code<=staged_code[1:0];result_review<=staged_review[1:0];
                            result_age<=0;result_seen<=1;telemetry_snapshot<=telemetry_live;
                        // An expired/replayed/incomplete prediction is a normal
                        // mailbox rejection, not a processor-bus fault. Keep
                        // the previous committed result and acknowledge OKAY.
                        // Linux checks result_end/status and the reject count.
                        end else rejected_commits<=rejected_commits+1'b1;
                    end
                    18'h000a4:begin
                        history_written<=0;
                        if(w_data==32'h48495331 && (&history_written) && history_mode &&
                           history_stage[0]==history_request && history_stage[6][7:0]<=100 && history_stage[6][15:8]<=100 &&
                           history_stage[6][23:16]<=100 && history_stage[6][15:8]<=history_stage[6][23:16] &&
                           history_stage[6][31:26]==0 &&
                           (history_stage[6][25:24]!=2 || history_stage[6][15:8]==history_stage[6][23:16]) &&
                           ((history_stage[6][25:24]==1 || history_stage[6][25:24]==2) || history_stage[6][23:8]==0) && history_stage[8]<=255 &&
                           (history_stage[7]&32'hfffff8f8)==0 && history_stage[7][7:0]<=4 &&
                           ((history_stage[7][7:0]>=3 && history_stage[1]==0) ||
                            (history_stage[7][7:0]<3 && history_stage[1]!=0)))begin
                            for(h=0;h<9;h=h+1)history_payload[h*32+:32]<=history_stage[h];
                            history_seen<=1;
                        end else history_rejected<=history_rejected+1'b1;
                    end
                    default:s_axi_bresp<=2;
                endcase
            end
            if(s_axi_rvalid && s_axi_rready) s_axi_rvalid<=0;
            if(s_axi_arvalid && s_axi_arready) begin
                read_pending<=1;read_ram<=s_axi_araddr[17];read_response<=0;
                read_register<=0;
                if(s_axi_araddr[1:0]!=0) begin read_ram<=0;read_response<=2;end
                else if(!s_axi_araddr[17]) case(s_axi_araddr)
                    18'h00000:read_register<=32'h534e5231;
                    18'h00004:read_register<=32'h00010004;
                    18'h00008:read_register<=produced;
                    18'h0000c:read_register<=SAMPLE_RATE;
                    18'h00010:read_register<=DEPTH;
                    18'h00014:read_register<=sample_age;
                    18'h00018:read_register<=CLK_HZ;
                    18'h0004c:read_register<=result_end;
                    18'h00050:read_register<={30'd0,research_status};
                    18'h00058:read_register<={30'd0,review_status};
                    18'h0005c:read_register<=rejected_commits;
                    18'h00060:read_register<=telemetry_snapshot[31:0];
                    18'h00064:read_register<=telemetry_snapshot[63:32];
                    18'h00068:read_register<=telemetry_snapshot[95:64];
                    18'h0006c:read_register<=telemetry_snapshot[127:96];
                    18'h00070:read_register<=telemetry_snapshot[159:128];
                    18'h000a8:read_register<=history_request;
                    18'h000ac:read_register<={31'd0,history_mode};
                    18'h000b0:read_register<=history_rejected;
                    18'h000b4:read_register<=history_payload[31:0];
                    18'h000b8:read_register<=history_offset;
                    default:read_response<=2;
                endcase
            end
            if(read_pending) begin
                read_pending<=0;s_axi_rvalid<=1;s_axi_rresp<=read_response;
                s_axi_rdata<=read_ram?read_ram_data:read_register;
            end
        end
    end
endmodule
