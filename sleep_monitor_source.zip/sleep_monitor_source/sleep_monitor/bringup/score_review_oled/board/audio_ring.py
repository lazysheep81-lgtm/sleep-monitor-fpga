"""No fabricated samples: snapshots are rejected on reset/overwrite/staleness."""
import numpy as np

MASK = 0xffffffff


class Discontinuity(RuntimeError):
    pass


class AudioRing:
    def __init__(self, io):
        self.io = io
        if io.read(0) != 0x534e5231 or io.read(4) != 0x10004:
            raise ValueError('Not the independent snore research overlay')
        self.rate = io.read(12)
        self.depth = io.read(16)
        self.clock = io.read(24)
        if (self.rate, self.depth, self.clock) != (15625, 32768, 50000000):
            raise ValueError('Unexpected hardware configuration')
        self.cursor = io.read(8)
        self.rejected_commits = io.read(0x5c)

    def take(self, limit=2048):
        before = self.io.read(8)
        count = (before-self.cursor) & MASK
        if self.io.read(20) >= self.clock//2:
            self.cursor = before
            raise Discontinuity('Audio not fresh')
        if count >= self.depth:
            self.cursor = before
            raise Discontinuity('Ring overwrite or capture reset')
        count = min(count, limit)
        if not count:
            return self.cursor, np.empty(0, dtype=np.int32)
        start = self.cursor
        index = start % self.depth
        first = min(count, self.depth-index)
        base = 0x20000//4
        a = self.io.array[base+index:base+index+first].copy()
        if first != count:
            a = np.concatenate((a, self.io.array[base:base+count-first].copy()))
        after = self.io.read(8)
        # An overwrite at ANY point in the copy invalidates the entire chunk.
        if ((after-before) & MASK) >= self.depth or ((after-start) & MASK) >= self.depth:
            self.cursor = after
            raise Discontinuity('Audio overwritten during copy')
        values = a.view(np.int32)
        if np.any(values < -8388608) or np.any(values > 8388607):
            self.cursor = after
            raise Discontinuity('Invalid sign extension')
        self.cursor = (start+count) & MASK
        return start, values

    def commit(self, end, status, review):
        if status not in (0, 1, 2, 3):
            raise ValueError('Invalid experimental status')
        if review not in (0,1,2,3) or (status==0 and review not in (0,2)) or (status==3 and review!=2):
            raise ValueError('Invalid or contradictory experimental review status')
        lag = (self.io.read(8)-end) & MASK
        if lag > self.rate+self.rate//2 or self.io.read(20) >= self.clock//2:
            return False
        rejected_before = self.io.read(0x5c)
        self.io.write(0x40, end & MASK)
        self.io.write(0x44, status)
        self.io.write(0x54, review)
        self.io.write(0x48, 0x534e5231)
        # A readback is also the write-ordering barrier before accepting commit.
        self.rejected_commits = self.io.read(0x5c)
        return (self.rejected_commits == rejected_before and
                self.io.read(0x4c) == (end & MASK) and self.io.read(0x50) == status and
                self.io.read(0x58)==review)

    def telemetry(self,end):
        values=[self.io.read(a) for a in (0x60,0x64,0x68,0x6c,0x70)]
        if self.io.read(0x4c)!=(end&MASK):raise Discontinuity('Telemetry snapshot changed')
        motion,bpm,mic,events,cs=values
        return dict(movement_count=(motion&0xffffff) if motion>>31 else None,
                    bpm=(bpm&255) if bpm&256 else None,
                    mic_peak_mean=(mic&0xffffff) if mic>>31 else None,
                    sound_event_count=(events&0xffffff) if events>>31 else None,
                    last_event_centiseconds=(cs&0xffffff) if cs>>31 else None)

    def history_request(self):
        if not self.io.read(0xac):return None
        tag=self.io.read(0xa8);offset=self.io.read(0xb8)
        if self.io.read(0xa8)!=tag or not self.io.read(0xac):return None
        return tag,offset

    def commit_history(self,tag,payload):
        lo,hi,kind=(payload.get(n,0) for n in ('score_low','score_high','score_kind'))
        if any(not isinstance(v,int) for v in (lo,hi,kind)) or not 0<=lo<=hi<=100 or kind not in (0,1,2,3):
            raise ValueError('Invalid score payload')
        if (kind==2 and lo!=hi) or (kind in (0,3) and (lo or hi)):
            raise ValueError('Contradictory score payload')
        values=[tag]+[payload[n] for n in ('run_id','seconds','bouts','reviews','moves','quality','state','bpm')]
        if any(not isinstance(v,int) or not 0<=v<=MASK for v in values):raise ValueError('Invalid history payload')
        if payload['quality']>100 or payload['bpm']>255 or payload['state']&0xfffff8f8 or payload['state']&255>4:
            raise ValueError('Invalid history flags')
        values[6] |= (lo<<8)|(hi<<16)|(kind<<24)
        before=self.io.read(0xb0)
        for i,value in enumerate(values):self.io.write(0x80+4*i,value)
        self.io.write(0xa4,0x48495331)
        return (self.io.read(0xb0)==before and self.io.read(0xb4)==tag and
                self.io.read(0xa8)==tag and bool(self.io.read(0xac)))
