"""Course-demo audio-review cues. No medical score or healthy state exists."""
from collections import deque
from copy import deepcopy
import hashlib
import json
from pathlib import Path


class ReviewTracker:
    def __init__(self,rate=15625,hop=12500,window=15234):
        self.rate,self.hop,self.window=rate,hop,window
        rules=Path(__file__).with_name('demo_rules.json')
        self.rules=json.loads(rules.read_text(encoding='utf-8'))
        self.rules_sha256=hashlib.sha256(rules.read_bytes()).hexdigest()
        if not (self.rules['demo_parameters_are_not_medical_thresholds'] and self.rules['healthy_output_forbidden']):
            raise ValueError('Only explicitly experimental audio-review rules are supported')
        if self.rules['rolling_seconds']!=60 or round(self.rules['window_seconds']*rate)!=window:
            raise ValueError('Rule/audio layout mismatch')
        self.last_raw=None;self.now=0;self.origin=0
        self.windows=deque();self.bouts=deque();self.can_start=True

    def propose(self,end,status):
        copy=deepcopy(self)
        return copy,copy.observe(end,status)

    @staticmethod
    def union(intervals,begin,end):
        total=0;last_end=begin
        for a,b in sorted(intervals):
            a=max(a,begin);b=min(b,end)
            if b>a:
                total+=max(0,b-max(a,last_end));last_end=max(last_end,b)
        return total

    def invalidate(self):
        self.last_raw=None;self.windows.clear();self.bouts.clear()
        self.now=0;self.origin=0;self.can_start=False

    def observe(self,end,status):
        if not 0<=end<=0xffffffff or status not in (0,1,2,3):raise ValueError('Invalid committed observation')
        gap=False
        if self.last_raw is None:
            self.now=end;self.origin=self.now
        else:
            delta=(end-self.last_raw)&0xffffffff
            if delta!=self.hop:
                self.windows.clear();self.bouts.clear();self.can_start=False
                self.now+=self.hop;self.origin=self.now;gap=True
            else:self.now+=delta
        self.last_raw=end
        self.windows.append((self.now-self.window,self.now,status))
        if status==1 and self.can_start:
            self.bouts.append(self.now);self.can_start=False
        elif status==2:self.can_start=True
        begin=self.now-60*self.rate
        while self.windows and self.windows[0][1]<=begin:self.windows.popleft()
        while self.bouts and self.bouts[0]<=begin:self.bouts.popleft()
        valid=self.union([(a,b) for a,b,s in self.windows if s in (1,2)],begin,self.now)/self.rate
        support=self.union([(a,b) for a,b,s in self.windows if s==1],begin,self.now)/self.rate
        age=(self.now-self.origin)/self.rate
        if gap or status==3:code,reason=2,'audio_bad_or_sequence_gap'
        elif status==0:code,reason=0,'current_model_ambiguous'
        elif age<60:code,reason=0,'collecting_first_continuous_minute'
        elif valid<60*self.rules['min_valid_coverage_fraction']:code,reason=2,'insufficient_determinate_window_coverage'
        elif (len(self.bouts)>=self.rules['review_if_candidate_bouts_at_least'] or
              support>=self.rules['review_if_candidate_union_seconds_at_least']):
            code,reason=1,'demo_repeated_candidate_sound_review_audio'
        else:code,reason=3,'demo_observing_not_a_health_clearance'
        return dict(code=code,reason=reason,candidate_bouts_60s=len(self.bouts),
                    candidate_window_support_seconds_60s=support,
                    determinate_window_coverage_seconds_60s=valid,
                    continuous_observation_seconds=age,demo_only=True,
                    clinical_risk_assessed=False,rules_sha256=self.rules_sha256)
