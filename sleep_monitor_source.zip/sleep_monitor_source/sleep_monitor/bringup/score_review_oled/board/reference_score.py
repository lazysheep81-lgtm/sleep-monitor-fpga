"""Unvalidated engineering reference index; never measures actual sleep quality."""
import argparse,json,math
from pathlib import Path


SCORE_VERSION='experimental_reference_v1'

def calculate(record,interval_cv=None,demo=False):
    result=dict(name='夜间监测参考分',score_version=SCORE_VERSION,experimental=True,clinical_validation=False,
                actual_sleep_time_measured=False,score=None,score_range=None,
                mode='DEMO' if demo else 'REFERENCE',deductions={},missing=[])
    def number(key):
        v=record.get(key)
        if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<0:
            raise ValueError('Invalid '+key)
        return v
    duration=number('duration_seconds')
    valid=number('candidate_windows')+number('other_windows')
    accepted=number('accepted_windows')
    if valid>accepted:raise ValueError('Class counts exceed accepted windows')
    # Nonoverlapping 0.8-second decision ticks, not the true sound duration.
    coverage=min(1,valid*.8/duration) if duration else 0
    result.update(observation_seconds=duration,determinate_coverage=coverage,
                  duration_is_decision_tick_estimate=True)
    if duration<(60 if demo else 1800) or coverage<.8:
        result['status']='INSUFFICIENT_DATA';return result
    movement=record.get('movement_count')
    if movement is None:
        result.update(status='MISSING_MOTION');result['missing'].append('movement');return result
    movement=number('movement_count')
    snore_fraction=number('candidate_windows')/valid if valid else 0
    bouts_per_minute=number('candidate_bouts')/(duration/60)
    moves_per_hour=movement/(duration/3600)
    # Course-demo choices. Not clinical thresholds or calibrated measurements.
    deductions=dict(candidate_coverage=40*min(1,snore_fraction/.30),
                    candidate_frequency=20*min(1,bouts_per_minute/10),
                    movement=30*min(1,moves_per_hour/30))
    result.update(candidate_fraction=snore_fraction,candidate_bouts_per_minute=bouts_per_minute,
                  movement_engineering_counts_per_hour=moves_per_hour)
    remaining=100-sum(deductions.values())
    if interval_cv is None:
        result['missing'].append('onset_interval_cv')
        result.update(status='PARTIAL_INDEX',score_range=[round(max(0,remaining-10)),round(max(0,remaining))])
    else:
        if isinstance(interval_cv,bool) or not math.isfinite(interval_cv) or interval_cv<0:
            raise ValueError('Invalid interval CV')
        deductions['interval_variability']=10*min(1,interval_cv/.5)
        result.update(status='EXPERIMENTAL_INDEX',score=round(max(0,remaining-deductions['interval_variability'])))
    result['deductions']={k:round(v,2) for k,v in deductions.items()}
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('record',type=Path)
    p.add_argument('--interval-cv',type=float);p.add_argument('--demo',action='store_true')
    a=p.parse_args();print(json.dumps(calculate(json.loads(a.record.read_text(encoding='utf-8-sig')),a.interval_cv,a.demo),ensure_ascii=False,indent=2))


if __name__=='__main__':main()
