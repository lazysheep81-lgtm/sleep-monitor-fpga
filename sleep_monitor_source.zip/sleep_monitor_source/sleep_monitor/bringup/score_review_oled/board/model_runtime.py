"""Fixed YAMNet inference, usable on board Python 3.8 and host for equivalence tests."""
import hashlib
from pathlib import Path
import sys
import zipfile
import numpy as np

MODEL_HASH = '4d8b4a53282dc83ef04e3e7dbc4fbc98082e34e44ed798e16c3a0cdd4c584faf'
SIZE = 15600
HOP_SECONDS = .8


def resample(values, source_rate, target_rate=16000):
    x = np.asarray(values, dtype=np.float64)
    if source_rate == target_rate:
        return x.copy()
    if len(x) < 2 or source_rate < 15000:
        raise ValueError('Insufficient input duration or bandwidth')
    padding = min(round(.1*source_rate), len(x)-1)
    if source_rate == 15625:
        # Exact 128/125 conversion with FFT-friendly lengths on Cortex-A9.
        count_source = ((len(x)+2*padding+4999)//5000)*5000
        padding = (count_source-len(x))//2
        padded = np.pad(x, (padding, count_source-len(x)-padding), mode='reflect')
    else:
        padded = np.pad(x, (padding, padding), mode='reflect')
    count = round(len(padded)*target_rate/source_rate)
    spectrum = np.fft.rfft(padded)
    output = np.zeros(count//2+1, dtype=np.complex128)
    keep = min(count, len(padded))
    output[:keep//2+1] = spectrum[:keep//2+1]
    if keep % 2 == 0:
        output[keep//2] *= 2 if count < len(padded) else .5
    converted = np.fft.irfft(output, n=count)*(count/len(padded))
    start = round(padding*target_rate/source_rate)
    return converted[start:start+round(len(x)*target_rate/source_rate)]


class Model:
    def __init__(self, path=None, host_test=False, host_runtime=None):
        path = Path(path or Path(__file__).with_name('yamnet.tflite'))
        if hashlib.sha256(path.read_bytes()).hexdigest() != MODEL_HASH:
            raise ValueError('Fixed model hash mismatch')
        with zipfile.ZipFile(path) as archive:
            self.labels = archive.read('yamnet_label_list.txt').decode().splitlines()
        if len(self.labels) != 521 or self.labels[38] != 'Snoring':
            raise ValueError('Unexpected label map')
        self.runtime_identity = None
        if host_test:
            if host_runtime is None:
                raise ValueError('Host comparison requires the pinned official TF 2.7 runtime path')
            runtime = Path(host_runtime).resolve()
            import json
            reference = json.loads(path.with_name('golden').joinpath('manifest.json').read_text())['reference_backend']
            if hashlib.sha256((runtime/'tflite_runtime/_pywrap_tensorflow_interpreter_wrapper.pyd').read_bytes()).hexdigest() != reference['binary_sha256']:
                raise ValueError('Host reference runtime hash mismatch')
            sys.path.insert(0, str(runtime))
            from tflite_runtime.interpreter import Interpreter, OpResolverType
        else:
            runtime = Path(__file__).with_name('vendor_arm_cortex_a9')
            import json
            provenance = json.loads((runtime/'A9_BUILD.json').read_text())
            binary = runtime/'tflite_runtime/_pywrap_tensorflow_interpreter_wrapper.so'
            if not (provenance.get('cpu') == 'cortex-a9' and
                    provenance.get('instruction_audit_passed') and
                    hashlib.sha256(binary.read_bytes()).hexdigest() == provenance.get('binary_sha256')):
                raise RuntimeError('Complete and verify the Cortex-A9 runtime build first')
            self.runtime_identity = provenance
            sys.path.insert(0, str(runtime))
            import tflite_runtime
            if Path(tflite_runtime.__file__).resolve().parent != (runtime/'tflite_runtime').resolve():
                raise RuntimeError('Another TFLite runtime is already imported')
            if tflite_runtime.__version__ != '2.7.0':
                raise RuntimeError('Use the checked local ARM runtime 2.7.0')
            from tflite_runtime.interpreter import Interpreter, OpResolverType
        import json
        derived = json.loads(path.with_name('reference_models.json').read_text())
        if derived['source_model_sha256'] != MODEL_HASH or derived['neural_resolver'] != 'BUILTIN_REF':
            raise ValueError('Unexpected reference model provenance')
        for name, digest in derived['files'].items():
            if hashlib.sha256(path.with_name(name).read_bytes()).hexdigest() != digest:
                raise ValueError('Derived model hash mismatch')
        self.frontend = Interpreter(model_path=str(path.with_name('yamnet_frontend.tflite')), num_threads=2,
                                    experimental_op_resolver_type=OpResolverType.BUILTIN_WITHOUT_DEFAULT_DELEGATES)
        self.frontend.allocate_tensors()
        self.front_input = self.frontend.get_input_details()[0]
        self.front_output = self.frontend.get_output_details()[0]
        self.interpreter = Interpreter(model_path=str(path.with_name('yamnet_classifier_ref.tflite')),
                                       num_threads=2, experimental_op_resolver_type=OpResolverType.BUILTIN_REF)
        self.interpreter.allocate_tensors()
        self.input = self.interpreter.get_input_details()[0]
        self.output = self.interpreter.get_output_details()[0]
        if tuple(self.front_input['shape']) != (SIZE,) or self.front_input['dtype'] != np.float32:
            raise ValueError('Unexpected waveform input ABI')
        if tuple(self.input['shape']) != (1, 96, 64) or self.input['dtype'] != np.int8:
            raise ValueError('Unexpected classifier input ABI')
        if (tuple(self.front_output['shape']) != tuple(self.input['shape']) or
                self.front_output['quantization'] != self.input['quantization']):
            raise ValueError('Frontend/classifier interface mismatch')
        if tuple(self.output['shape']) != (1, 521) or self.output['dtype'] != np.float32:
            raise ValueError('Unexpected score output ABI')

    def run(self, waveform):
        x = np.ascontiguousarray(waveform, dtype=np.float32)
        if x.shape != (SIZE,) or not np.isfinite(x).all() or np.max(np.abs(x)) > 1.00001:
            raise ValueError('Invalid waveform; no automatic gain or clipping')
        self.frontend.set_tensor(self.front_input['index'], x)
        self.frontend.invoke()
        self.interpreter.set_tensor(self.input['index'], self.frontend.get_tensor(self.front_output['index']))
        self.interpreter.invoke()
        result = self.interpreter.get_tensor(self.output['index'])[0].copy()
        if not np.isfinite(result).all() or result.min() < 0 or result.max() > 1:
            raise ValueError('Invalid score output')
        return result


def signal_valid(raw):
    x = np.asarray(raw)
    if x.ndim != 1 or not len(x) or not np.isfinite(x).all():
        return False
    # Engineering quality checks, not snore-class thresholds.
    return bool(np.max(np.abs(x.astype(np.int64))) <= 8388608 and
                np.count_nonzero(x) >= len(x)*.05 and
                np.count_nonzero(np.abs(x.astype(np.int64)) >= 8388000) < len(x)*.01 and
                np.max(x) != np.min(x))


def rank_status(scores):
    """Unique top class only; quantized ties are explicitly undetermined."""
    values = np.asarray(scores)
    if values.shape != (521,) or not np.isfinite(values).all():
        raise ValueError('Invalid class scores')
    winners = np.flatnonzero(values == values.max())
    if len(winners) != 1:
        return 0, winners.tolist()
    return (1 if int(winners[0]) == 38 else 2), winners.tolist()
