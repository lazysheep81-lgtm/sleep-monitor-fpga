"""Durable experimental session summaries; disk work never runs in inference.

Board wall-clock values are unverified metadata, never record identifiers.
Candidate bouts and review entries are engineering counts, not clinical events.
"""
from datetime import datetime, timezone
import os
from pathlib import Path
import queue
import sqlite3
import threading
import time
import uuid
import math
from reference_score import calculate

FIELDS = {
    'session_uuid':'TEXT NOT NULL UNIQUE', 'boot_id':'TEXT NOT NULL',
    'board_clock_utc':'TEXT NOT NULL', 'clock_verified':'INTEGER NOT NULL',
    'model_sha256':'TEXT NOT NULL', 'rules_sha256':'TEXT NOT NULL',
    'state':'TEXT NOT NULL', 'end_reason':'TEXT NOT NULL',
    'duration_seconds':'INTEGER NOT NULL', 'accepted_windows':'INTEGER NOT NULL',
    'candidate_windows':'INTEGER NOT NULL', 'candidate_bouts':'INTEGER NOT NULL',
    'review_entries':'INTEGER NOT NULL', 'other_windows':'INTEGER NOT NULL',
    'uncertain_windows':'INTEGER NOT NULL', 'bad_windows':'INTEGER NOT NULL',
    'uncommitted_windows':'INTEGER NOT NULL', 'gap_events':'INTEGER NOT NULL',
    'capture_gap_count':'INTEGER NOT NULL','skipped_decision_windows':'INTEGER NOT NULL',
    'movement_count':'INTEGER', 'sound_event_count':'INTEGER',
    'last_event_centiseconds':'INTEGER', 'mic_peak_mean':'INTEGER',
    'bpm_count':'INTEGER NOT NULL', 'bpm_sum':'INTEGER NOT NULL',
    'bpm_min':'INTEGER', 'bpm_max':'INTEGER', 'checkpoint_sequence':'INTEGER NOT NULL',
}


class Summary:
    def __init__(self, boot_id, model_sha256, rules_sha256, now=None):
        self.started = time.monotonic() if now is None else now
        self.data = {n:0 for n in FIELDS}
        self.data.update(session_uuid=uuid.uuid4().hex, boot_id=boot_id,
            board_clock_utc=datetime.now(timezone.utc).isoformat(), clock_verified=0,
            model_sha256=model_sha256, rules_sha256=rules_sha256,
            state='open', end_reason='', movement_count=None, sound_event_count=None,
            last_event_centiseconds=None, mic_peak_mean=None, bpm_min=None,bpm_max=None)
        self.last_sequence = None
        self.can_start = True
        self.last_review = None
        self.rhythm_anchor=None;self.rhythm_n=0;self.rhythm_mean=0.;self.rhythm_m2=0.
        self.rhythm_last_status=None;self.rhythm_seq=0

    def observe(self, end, status, accepted, review, telemetry=None):
        if status not in (0,1,2,3) or review not in (0,1,2,3):
            raise ValueError('Invalid inference status')
        d=self.data
        discontinuous=(self.last_sequence is not None and ((end-self.last_sequence)&0xffffffff)!=12500)
        if not accepted or status not in (1,2) or discontinuous:
            self.rhythm_anchor=None;self.rhythm_last_status=None
        if accepted:
            self.rhythm_seq+=1
            if status==1 and self.rhythm_last_status==2:
                if self.rhythm_anchor is not None:
                    interval=(self.rhythm_seq-self.rhythm_anchor)*.8
                    self.rhythm_n+=1;delta=interval-self.rhythm_mean
                    self.rhythm_mean+=delta/self.rhythm_n
                    self.rhythm_m2+=delta*(interval-self.rhythm_mean)
                self.rhythm_anchor=self.rhythm_seq
            self.rhythm_last_status=status if status in (1,2) else None
        if not accepted:
            d['uncommitted_windows']+=1
            self.can_start=False;self.last_review=None
            return
        if self.last_sequence is not None and ((end-self.last_sequence)&0xffffffff)!=12500:
            d['gap_events']+=1;self.can_start=False;self.last_review=None
        self.last_sequence=end
        d['accepted_windows']+=1
        d[{0:'uncertain_windows',1:'candidate_windows',2:'other_windows',3:'bad_windows'}[status]]+=1
        if status==1 and self.can_start:
            d['candidate_bouts']+=1;self.can_start=False
        elif status==2:self.can_start=True
        if review==1 and self.last_review!=1:d['review_entries']+=1
        self.last_review=review
        for key in ('movement_count','sound_event_count','mic_peak_mean'):
            value=(telemetry or {}).get(key)
            if value is not None:d[key]=max(d[key] or 0,int(value))
        if (telemetry or {}).get('last_event_centiseconds') is not None:
            d['last_event_centiseconds']=int(telemetry['last_event_centiseconds'])
        bpm=(telemetry or {}).get('bpm')
        if bpm is not None and 0<int(bpm)<=255:
            bpm=int(bpm);d['bpm_count']+=1;d['bpm_sum']+=bpm
            d['bpm_min']=bpm if d['bpm_min'] is None else min(d['bpm_min'],bpm)
            d['bpm_max']=bpm if d['bpm_max'] is None else max(d['bpm_max'],bpm)

    def snapshot(self, now=None, state='open', reason=''):
        d=dict(self.data);now=time.monotonic() if now is None else now
        d.update(duration_seconds=max(0,int(now-self.started)),state=state,end_reason=str(reason)[:256])
        self.data['checkpoint_sequence']+=1
        d['checkpoint_sequence']=self.data['checkpoint_sequence']
        d.update(rhythm_n=self.rhythm_n,rhythm_mean=self.rhythm_mean,rhythm_m2=self.rhythm_m2)
        return d


class WriterLock:
    def __init__(self,path):
        self.file=Path(path).open('a+b')
        if self.file.tell()==0:self.file.write(b'0');self.file.flush()
        self.file.seek(0)
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(self.file.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BaseException:
            self.file.close();raise
    def close(self):
        if self.file.closed:return
        self.file.seek(0)
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(self.file.fileno(),msvcrt.LK_UNLCK,1)
        else:
            import fcntl
            fcntl.flock(self.file.fileno(),fcntl.LOCK_UN)
        self.file.close()


class Store:
    """Single-writer SQLite connection, owned by the storage worker thread."""
    def __init__(self,path,initial):
        path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
        self.lock=WriterLock(path.with_suffix('.writer.lock'))
        self.db=None
        try:
            self.db=sqlite3.connect(str(path),timeout=.025,isolation_level=None)
            self.db.row_factory=sqlite3.Row
            if self.db.execute('PRAGMA quick_check').fetchone()[0]!='ok':
                raise RuntimeError('History database integrity check failed')
            version=self.db.execute('PRAGMA user_version').fetchone()[0]
            if version not in (0,1):raise RuntimeError('Unknown history schema; preserved without replacement')
            if self.db.execute('PRAGMA journal_mode=WAL').fetchone()[0].lower()!='wal':
                raise RuntimeError('History requires SQLite WAL')
            self.db.execute('PRAGMA synchronous=FULL')
            self.db.execute('CREATE TABLE IF NOT EXISTS sessions (id INTEGER PRIMARY KEY AUTOINCREMENT,'+
                ','.join(n+' '+t for n,t in FIELDS.items())+
                ", CHECK (state IN ('open','complete','interrupted')))")
            self.db.execute('CREATE TABLE IF NOT EXISTS reference_rhythm (session_uuid TEXT PRIMARY KEY, n INTEGER NOT NULL, mean REAL NOT NULL, m2 REAL NOT NULL)')
            self.db.execute('PRAGMA user_version=1')
            self.db.execute('BEGIN IMMEDIATE')
            try:
                self.db.execute("UPDATE sessions SET state='interrupted',end_reason='Previous process ended without final save' WHERE state='open'")
                keys=list(FIELDS)
                cur=self.db.execute('INSERT INTO sessions ('+','.join(keys)+') VALUES ('+','.join('?' for _ in keys)+')',
                                    [initial[n] for n in keys])
                self.id=cur.lastrowid;self.db.execute('COMMIT')
            except BaseException:
                self.db.execute('ROLLBACK');raise
        except BaseException:
            self.close();raise

    def save(self,data):
        keys=[n for n in FIELDS if n not in ('session_uuid','boot_id','board_clock_utc','model_sha256','rules_sha256')]
        self.db.execute('BEGIN IMMEDIATE')
        try:
            cur=self.db.execute('UPDATE sessions SET '+','.join(n+'=?' for n in keys)+
                " WHERE id=? AND state='open'",[data[n] for n in keys]+[self.id])
            if cur.rowcount!=1:raise RuntimeError('Current history record is no longer open')
            self.db.execute('INSERT OR REPLACE INTO reference_rhythm VALUES (?,?,?,?)',
                (data['session_uuid'],data.get('rhythm_n',0),data.get('rhythm_mean',0.),data.get('rhythm_m2',0.)))
            self.db.execute('COMMIT')
        except BaseException:
            self.db.execute('ROLLBACK');raise

    def selected(self,offset):
        count=self.db.execute('SELECT COUNT(*) FROM sessions').fetchone()[0]
        if not count:return None
        row=self.db.execute('SELECT * FROM sessions ORDER BY id DESC LIMIT 1 OFFSET ?',
                            (int(offset)%count,)).fetchone()
        result=dict(row)
        rhythm=self.db.execute('SELECT n,mean,m2 FROM reference_rhythm WHERE session_uuid=?',(row['session_uuid'],)).fetchone()
        result['interval_cv']=(math.sqrt(max(0,rhythm[2])/rhythm[0])/rhythm[1] if rhythm and rhythm[0]>=5 and rhythm[1]>0 else None)
        return result

    def close(self):
        if self.db is not None:self.db.close();self.db=None
        self.lock.close()


def display_payload(row,score_view=False):
    if row is None:return dict(run_id=0,seconds=0,bouts=0,reviews=0,moves=0,quality=0,state=3,bpm=0)
    n=row['accepted_windows']
    quality=round(100*(row['candidate_windows']+row['other_windows'])/n) if n else 0
    bpm=round(row['bpm_sum']/row['bpm_count']) if row['bpm_count'] else 0
    result=dict(run_id=row['id'],seconds=row['duration_seconds'],bouts=row['candidate_bouts'],
                reviews=row['review_entries'],moves=row['movement_count'] or 0,quality=quality,
                state=({'open':0,'complete':1,'interrupted':2}[row['state']] |
                       (0x100 if row['movement_count'] is not None else 0) | (0x200 if n else 0)),bpm=bpm)
    if score_view:
        score=calculate(row,row.get('interval_cv'))
        kind={'INSUFFICIENT_DATA':0,'MISSING_MOTION':3,'PARTIAL_INDEX':1,'EXPERIMENTAL_INDEX':2}[score['status']]
        lo,hi=(score['score_range'] if kind==1 else [score['score'],score['score']] if kind==2 else [0,0])
        result.update(score_low=lo,score_high=hi,score_kind=kind,state=result['state']|0x400)
    if any(not isinstance(v,int) or not 0<=v<=0xffffffff for v in result.values()) or quality>100 or bpm>255:
        raise ValueError('Saved history value cannot be displayed safely')
    return result


class History:
    """Latest-only checkpoint queue, bounded error reporting, no inference I/O."""
    def __init__(self,path,summary):
        self.path=Path(path);self.summary=summary
        self.jobs=queue.Queue(maxsize=1);self.replies=queue.Queue(maxsize=1)
        self.ready=threading.Event();self.id=None;self.error=None;self.saved_windows=0
        self.initial=summary.snapshot()
        self.worker=threading.Thread(target=self._worker,daemon=True)
        self.worker.start()
        if not self.ready.wait(5):self.error='History initialization still pending'

    @staticmethod
    def latest(q,value):
        while True:
            try:q.put_nowait(value);return
            except queue.Full:
                try:q.get_nowait()
                except queue.Empty:pass

    def _worker(self):
        store=None
        try:
            store=Store(self.path,self.initial);self.id=store.id;self.error=None
        except BaseException as e:self.error=repr(e)[:256]
        finally:self.ready.set()
        while True:
            data,nav,final=self.jobs.get()
            try:
                if store is None:raise RuntimeError(self.error or 'History unavailable')
                store.save(data);self.saved_windows=data['accepted_windows'];self.error=None
                if nav is not None:
                    tag,offset=nav;self.latest(self.replies,(tag,display_payload(store.selected(offset//2),score_view=(offset%2==0))))
            except BaseException as e:
                self.error=repr(e)[:256]
                if nav is not None:self.latest(self.replies,(nav[0],dict(run_id=0,seconds=0,bouts=0,
                    reviews=0,moves=0,quality=0,state=4,bpm=0)))
            if final:
                if store is not None:store.close()
                return

    def checkpoint(self,nav=None):
        self.latest(self.jobs,(self.summary.snapshot(),nav,False))

    def response(self):
        try:return self.replies.get_nowait()
        except queue.Empty:return None

    def finish(self,complete=True,reason='normal stop'):
        self.latest(self.jobs,(self.summary.snapshot(state='complete' if complete else 'interrupted',reason=reason),None,True))
        self.worker.join(timeout=7)
        if self.worker.is_alive():self.error='Final history save has not completed'
        return self.error is None
