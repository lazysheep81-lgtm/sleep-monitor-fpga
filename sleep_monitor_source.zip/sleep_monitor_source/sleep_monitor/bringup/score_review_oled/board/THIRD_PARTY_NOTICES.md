# Third-party notices

## YAMNet model and TensorFlow Lite runtime

Google YAMNet fixed pretrained model, Apache License2.0.
Source supplied by Google's MediaPipe web audio-classifier example:
https://storage.googleapis.com/mediapipe-models/audio_classifier/yamnet/float32/1/yamnet.tflite

Model SHA256: `4d8b4a53282dc83ef04e3e7dbc4fbc98082e34e44ed798e16c3a0cdd4c584faf`.
The model weights have not been changed or trained in this project.

TensorFlow Lite runtime2.7.0, The TensorFlow Authors, Apache License2.0.
The ARM binary in this package is built locally from TensorFlow v2.7.0
for Cortex-A9 / NEON / VFPv3. It replaces the incompatible upstream ARM
wheel; the failing wheel is not bundled here. Runtime provenance, compiler
flags and the binary hash are in `vendor_arm_cortex_a9/A9_BUILD.json`.
Apache license text is included in `LICENSE-APACHE-2.0.txt`.

Pinned dependencies and their license texts are retained in `licenses/`.
The complete filtered source package and native builder are supplied in
the final project delivery. See its source manifest for upstream URLs/hashes.

The fixed model is split at tensor 28 into a built-in frontend and a
reference-kernel classifier. Weights were not retrained or altered. This
avoids architecture-dependent optimized integer kernel score differences.
`reference_models.json` identifies both derived graphs and their source.

Application integration and numerical probes were added for this board.

## Public sound excerpts

Numerical waveform vectors `public_clip_01.npy` and `public_clip_04.npy` are
modified excerpts of *Breathing and Snoring*, naturenotesuk, Freesound761638:
https://freesound.org/people/naturenotesuk/sounds/761638/
License: https://creativecommons.org/licenses/by/4.0/

Preview decoded, shared gain, selected excerpt, 16kHz resampling and float32
window extraction. These vectors contain only short portions of the preview.
They are numerical comparisons, not an accuracy-validation dataset.
See `golden/ATTRIBUTION.md` and `golden/manifest.json` for provenance.

Board speech/environment vectors are local user experiment recordings supplied
for this prototype, for local device testing. No third-party voice upload.
