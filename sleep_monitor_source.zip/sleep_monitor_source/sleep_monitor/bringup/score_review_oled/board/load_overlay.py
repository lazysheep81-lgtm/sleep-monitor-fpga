"""Load the checked research overlay into volatile PL; no flash/boot changes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
from verify_bundle import verify
from model_runtime import MODEL_HASH


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--experimental',action='store_true')
    args = parser.parse_args()
    if not args.experimental or platform.machine() not in ('armv7l','armv7') or os.geteuid()!=0:
        parser.error('Require root on ARMv7 and explicit --experimental')
    root = Path(__file__).resolve().parent
    verify()
    report = json.loads((root/'arm_probe.json').read_text())
    if not (report['arm_execution'] and report['passed'] and report['realtime_budget_passed'] and
            report['model_sha256']==MODEL_HASH and
            report['reference_models']==json.loads((root/'reference_models.json').read_text()) and
            report['adapter_sha256']==hashlib.sha256((root/'model_runtime.py').read_bytes()).hexdigest()):
        raise RuntimeError('ARM numerical and latency probe must pass before overlay use')
    from model_runtime import Model
    runtime = Model()
    if report.get('runtime_binary_sha256') != runtime.runtime_identity.get('binary_sha256'):
        raise RuntimeError('ARM probe runtime no longer matches')
    build = json.loads((root/'overlay/BUILD_INFO.json').read_text())
    if build.get('j2',{}).get('9',{}).get('pin') != 'K18' or build['j2'].get('10',{}).get('pin') != 'K17':
        raise RuntimeError('Overlay uses obsolete IMU pin mapping')
    from pynq import Overlay
    from audio_ring import AudioRing
    from pynq import MMIO
    overlay = Overlay(str(root/'overlay/standalone.bit'))
    ring = AudioRing(MMIO(0x40000000,0x40000))
    print('Overlay loaded. Audio rate',ring.rate,'depth',ring.depth,
          'OLED must still be checked; no health assessment implemented.')


if __name__ == '__main__':
    main()
