"""Independent ARM inference: no PC, network, UART audio or external predictions.

Explicit research switch required. Never reports clinical risk/health.
"""
import argparse
from datetime import datetime, timezone
import json
import hashlib
from pathlib import Path
import platform
import queue
import signal
import sys
import threading
import time
import numpy as np
from audio_ring import AudioRing, Discontinuity, MASK
from model_runtime import Model, resample, signal_valid, rank_status, MODEL_HASH, HOP_SECONDS
from review_tracker import ReviewTracker
from history_store import Summary,History


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--experimental', action='store_true')
    parser.add_argument('--seconds', type=float, default=60)
    parser.add_argument('--report', type=Path, default=Path('live_research.jsonl'))
    parser.add_argument('--history-db',type=Path,default=Path(__file__).with_name('history')/'results.sqlite3')
    args = parser.parse_args()
    if not args.experimental or platform.machine() not in ('armv7l', 'armv7'):
        parser.error('Require explicit --experimental on the ARMv7 board')
    if args.seconds <= 0 or args.seconds > 86400:
        parser.error('Require 0 < seconds <= 86400')
    # Importing on Windows for tests never accesses hardware.
    from pynq import MMIO
    probe = json.loads(Path(__file__).with_name('arm_probe.json').read_text(encoding='utf-8'))
    if not (probe.get('passed') and probe.get('arm_execution') and
            probe.get('model_sha256') == MODEL_HASH and probe.get('realtime_budget_passed') and
            probe.get('reference_models') == json.loads(Path(__file__).with_name('reference_models.json').read_text()) and
            probe.get('adapter_sha256') == hashlib.sha256(Path(__file__).with_name('model_runtime.py').read_bytes()).hexdigest()):
        raise RuntimeError('Complete the ARM equivalence/latency probe before live research display')
    stop = threading.Event()
    stop_reason={'value':'time limit'}
    def request_stop(signum,frame):
        stop_reason['value']='signal '+str(signum);stop.set()
    signal.signal(signal.SIGTERM,request_stop)
    signal.signal(signal.SIGINT,request_stop)
    model = Model()
    if probe.get('runtime_binary_sha256') != model.runtime_identity.get('binary_sha256'):
        raise RuntimeError('Runtime changed after ARM probe')
    if model.labels[int(np.argmax(model.run(np.zeros(15600, np.float32))))] != 'Silence':
        raise RuntimeError('Model smoke test failed')
    ring = AudioRing(MMIO(0x40000000, 0x40000))
    size, hop = round(.975*ring.rate), round(HOP_SECONDS*ring.rate)
    tracker = ReviewTracker(ring.rate,hop,size)
    jobs = queue.Queue(maxsize=1)
    summary=Summary(Path('/proc/sys/kernel/random/boot_id').read_text().strip(),MODEL_HASH,tracker.rules_sha256)
    history=History(args.history_db,summary)
    ring.cursor=ring.io.read(8)
    lock = threading.Lock()
    health = dict(generation=0, gaps=0, skipped_decision_windows=0, reader_error=None)
    started = time.monotonic();summary.started=started
    last_checkpoint=started;last_ui=started;last_nav=None

    def service_history():
        nonlocal last_checkpoint,last_ui,last_nav
        now=time.monotonic();nav=ring.history_request()
        if now-last_checkpoint>=10 or (nav is not None and (nav!=last_nav or now-last_ui>=5)):
            history.checkpoint(nav);last_checkpoint=now;last_ui=now;last_nav=nav
        reply=history.response()
        if reply is not None:
            accepted=ring.commit_history(*reply)
            log.write(json.dumps(dict(type='history_display',tag=reply[0],payload=reply[1],committed=bool(accepted)))+'\n');log.flush()

    def reader():
        buffer = np.empty(0, dtype=np.int32)
        base = ring.cursor
        while not stop.is_set():
            try:
                seq, samples = ring.take()
                if not len(samples):
                    stop.wait(.005)
                    continue
                if ((base+len(buffer)) & MASK) != seq:
                    raise Discontinuity('Noncontiguous chunk')
                buffer = np.concatenate((buffer, samples))
                while len(buffer) >= size:
                    with lock:
                        generation = health['generation']
                    item = (generation, (base+size) & MASK, buffer[:size].copy())
                    try:
                        jobs.put_nowait(item)
                    except queue.Full:
                        try:
                            jobs.get_nowait()
                        except queue.Empty:
                            pass
                        with lock:
                            health['skipped_decision_windows'] += 1
                        jobs.put_nowait(item)
                    buffer = buffer[hop:].copy()
                    base = (base+hop) & MASK
            except Discontinuity:
                with lock:
                    health['generation'] += 1
                    health['gaps'] += 1
                buffer = np.empty(0, dtype=np.int32)
                base = ring.cursor
                try:
                    jobs.get_nowait()
                except queue.Empty:
                    pass
                stop.wait(.01)
            except Exception as error:
                with lock:
                    health['generation'] += 1
                    health['reader_error'] = repr(error)
                stop.set()
    thread = threading.Thread(target=reader, daemon=True)
    with args.report.open('x', encoding='utf-8') as log:
        log.write(json.dumps(dict(type='start', utc=datetime.now(timezone.utc).isoformat(),
                                  model_sha256=MODEL_HASH, architecture=platform.machine(),
                                  source='PL AXI ring, local ARM inference', research_only=True,
                                  risk='UNASSESSED', raw_rate=ring.rate, window=size, hop=hop,
                                  history_record_id=history.id,history_clock_verified=False))+'\n')
        thread.start()
        try:
            while time.monotonic()-started < args.seconds and not stop.is_set():
                service_history()
                try:
                    generation, end, raw = jobs.get(timeout=.25)
                except queue.Empty:
                    continue
                with lock:
                    if generation != health['generation']:
                        continue
                begin = time.monotonic()
                good = signal_valid(raw)
                top, score, candidates = None, None, []
                if good:
                    values = resample(raw.astype(np.float64)/8388608., ring.rate)
                    if len(values) != 15600:
                        raise RuntimeError('Unexpected resampling length')
                    scores = model.run(values)
                    status, winners = rank_status(scores)
                    candidates = [model.labels[i] for i in winners]
                    top = candidates[0] if len(candidates)==1 else 'AMBIGUOUS'
                    score = float(scores[38])
                else:
                    status = 3
                elapsed = time.monotonic()-begin
                proposal,review = tracker.propose(end,status)
                with lock:
                    unchanged = generation == health['generation'] and not stop.is_set()
                    accepted = unchanged and ring.commit(end, status, review['code'])
                telemetry=None
                if accepted:
                    tracker=proposal
                    try:telemetry=ring.telemetry(end)
                    except Discontinuity:pass
                else:tracker.invalidate()
                summary.observe(end,status,bool(accepted),review['code'],telemetry)
                with lock:
                    summary.data['capture_gap_count']=health['gaps']
                    summary.data['skipped_decision_windows']=health['skipped_decision_windows']
                item = dict(type='decision', end_sample=end, top=top, snoring_score=score,
                            mailbox_rejected_commits=ring.rejected_commits,
                            top_candidates=candidates,
                            status=status, committed=bool(accepted), inference_s=elapsed,
                            risk='EXPERIMENTAL_REVIEW_ONLY',review=review,research_only=True,
                            history_record_id=history.id,history_saved_windows=history.saved_windows,
                            history_error=history.error,
                            candidate_support_is_not_true_snore_duration=True)
                log.write(json.dumps(item)+'\n');log.flush()
                print(json.dumps(item), flush=True)
        finally:
            stop.set();thread.join(timeout=2)
            history_saved=history.finish(complete=(sys.exc_info()[0] is None and not health['reader_error']),
                                         reason=health['reader_error'] or stop_reason['value'])
            log.write(json.dumps(dict(type='history_stop',record_id=history.id,saved=history_saved,error=history.error))+'\n')
            log.write(json.dumps(dict(type='stop', health=health,
                                      hardware_expiry_seconds=1.5))+'\n')
    # No final 'healthy' or 'not snoring' message: hardware independently expires.
    if health['reader_error']:
        raise RuntimeError(health['reader_error'])


if __name__ == '__main__':
    main()
