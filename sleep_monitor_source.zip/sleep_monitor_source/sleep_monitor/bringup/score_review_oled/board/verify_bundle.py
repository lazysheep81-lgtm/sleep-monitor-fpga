"""Read-only verification of the files copied to the board; no target writes."""
import hashlib
import json
from pathlib import Path


def verify():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root/'bundle_manifest.json').read_text(encoding='utf-8'))
    for name, expected in manifest['files'].items():
        path = root/name
        if path.resolve().parent != root.resolve() and root.resolve() not in path.resolve().parents:
            raise ValueError('Invalid bundle path')
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('Bundle mismatch: '+name)
    print('Verified',len(manifest['files']),'files; hardware testing remains required')
    return manifest


if __name__ == '__main__':
    verify()
