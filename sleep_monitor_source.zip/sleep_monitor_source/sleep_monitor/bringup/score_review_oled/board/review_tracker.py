"""Drop-in experimental pattern cues using the existing 2-bit OLED risk code."""
import math
from base_review_tracker import ReviewTracker as Base


class ReviewTracker(Base):
    def observe(self,end,status):
        result=super().observe(end,status)
        begin=self.now-60*self.rate
        # Only consecutive confirmed candidate windows form a duration run.
        runs=[]
        a=b=None
        for start,stop,s in self.windows:
            if s==1:
                if a is None:a,b=start,stop
                elif start<=b:b=stop
                else:runs.append((a,b));a,b=start,stop
            elif a is not None:runs.append((a,b));a=b=None
        if a is not None:runs.append((a,b))
        longest=max([max(0,min(b,self.now)-max(a,begin))/self.rate for a,b in runs] or [0])
        # A missing/ambiguous decision can hide an onset: do not report rhythm.
        full_observation=(result['continuous_observation_seconds']>=60 and
                          all(s in (1,2) for _,_,s in self.windows))
        intervals=[(b-a)/self.rate for a,b in zip(self.bouts,list(self.bouts)[1:])]
        cv=None
        if full_observation and len(intervals)>=self.rules['pattern_min_intervals']:
            mean=sum(intervals)/len(intervals)
            cv=math.sqrt(sum((x-mean)**2 for x in intervals)/len(intervals))/mean
        flags=[]
        if result['candidate_bouts_60s']>=self.rules['pattern_frequency_bouts_per_minute']:flags.append('FREQUENT')
        if result['candidate_window_support_seconds_60s']>=self.rules['pattern_support_seconds_per_minute']:flags.append('HIGH_SUPPORT')
        if longest>=self.rules['pattern_longest_confirmed_seconds']:flags.append('LONG_RUN')
        if cv is not None and cv>=self.rules['pattern_interval_cv']:flags.append('IRREGULAR')
        ready=(result['continuous_observation_seconds']>=60 and
               result['determinate_window_coverage_seconds_60s']>=48 and status in (1,2))
        # Preserve bad/gap and insufficient-data priorities from the base tracker.
        if ready and result['code']!=2:
            result['code']=1 if flags else 3
            result['reason']='pattern_review:'+','.join(flags) if flags else 'no_demo_threshold_triggered_not_a_health_clearance'
        result.update(pattern_flags=flags if ready and result['code']!=2 else [],
                      longest_confirmed_candidate_seconds_60s=longest,
                      onset_interval_cv=cv,onset_intervals_used=len(intervals) if cv is not None else 0,
                      pattern_thresholds_are_not_medical=True,
                      silence_cannot_establish_apnea=True,
                      duration_is_model_window_support_not_true_snore_duration=True)
        return result
