"""Guarded service entry point, enabled only after real board verification."""
import argparse
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--experimental', action='store_true')
    args = parser.parse_args()
    if not args.experimental or os.geteuid() != 0 or platform.machine() not in ('armv7l', 'armv7'):
        parser.error('Require root on ARMv7 and explicit --experimental')
    root = Path(__file__).resolve().parent
    logs = root / 'recordings'
    logs.mkdir(exist_ok=True)
    env = dict(os.environ, XILINX_XRT='/usr', PYTHONUNBUFFERED='1', OPENBLAS_NUM_THREADS='1')
    # load_overlay independently verifies the package, runtime fingerprint,
    # ARM numerical/latency probe, and the corrected IMU pin mapping.
    subprocess.run([sys.executable, str(root / 'load_overlay.py'), '--experimental'],
                   env=env, cwd=str(root), check=True)
    boot_id = Path('/proc/sys/kernel/random/boot_id').read_text().strip()[:8]
    report = logs / ('live_' + boot_id + '_' + str(time.time_ns()) + '.jsonl')
    (logs / 'service_last_start.json').write_text(json.dumps(dict(
        report=str(report), mode='experimental_local_inference',
        boot_id=boot_id, clinical_validation=False,
        clock_note='Board wall-clock may be unset; decision ordering uses sample sequences'), indent=2) + '\n')
    os.chdir(root)
    os.execve(sys.executable, [sys.executable, str(root / 'run_research.py'),
                             '--experimental', '--seconds', '86400',
                             '--report', str(report)], env)


if __name__ == '__main__':
    main()
