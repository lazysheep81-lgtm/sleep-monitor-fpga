set stage [file normalize [file dirname [info script]]]
set parent [file normalize [file join $stage .. motion_buzzer_oled]]
set project_file [file join $stage build ps standalone.xpr]
set setup_marker [file join $stage build ps setup_complete]
if {[file exists $project_file] && ![file exists $setup_marker]} {
    # Preserve failed generated projects rather than opening an incomplete BD.
    file rename [file dirname $project_file] [file join $stage build ps_failed_[clock seconds]]
}
if {[file exists $project_file]} {
    open_project $project_file
} else {
    create_project standalone [file dirname $project_file] -part xc7z020clg400-2
    set_property target_language Verilog [current_project]
    foreach f [concat [glob [file join $parent rtl *.v]] [glob [file join $parent rtl *.sv]]] {
        if {[file tail $f] ni {ppg_oled_top.v oled_live_client.v ppg_screen_rom.v i2c_startup_clear.v shared_i2c_bus.v}} {add_files $f}
    }
    add_files [glob [file join $stage rtl *.v]]
    add_files [file join $stage .. .. rtl uart.v]
    add_files -fileset constrs_1 [file join $parent constraints shared.xdc]
    create_bd_design s
    create_bd_cell -type ip -vlnv xilinx.com:ip:processing_system7:5.5 ps7_0
    source [file join $stage reference ps_config.tcl]
    make_bd_intf_pins_external [get_bd_intf_pins ps7_0/DDR]
    make_bd_intf_pins_external [get_bd_intf_pins ps7_0/FIXED_IO]
    create_bd_cell -type module -reference standalone_core core
    set axi [create_bd_cell -type ip -vlnv xilinx.com:ip:axi_interconnect:2.1 axi]
    set_property -dict [list CONFIG.NUM_SI {1} CONFIG.NUM_MI {1}] $axi
    connect_bd_intf_net [get_bd_intf_pins ps7_0/M_AXI_GP0] [get_bd_intf_pins axi/S00_AXI]
    connect_bd_intf_net [get_bd_intf_pins axi/M00_AXI] [get_bd_intf_pins core/s_axi]
    create_bd_cell -type ip -vlnv xilinx.com:ip:proc_sys_reset:5.0 reset
    create_bd_cell -type ip -vlnv xilinx.com:ip:xlconstant:1.1 one
    set_property CONFIG.CONST_VAL 1 [get_bd_cells one]
    connect_bd_net [get_bd_pins one/dout] [get_bd_pins reset/dcm_locked]
    set c [create_bd_port -dir I -type clk -freq_hz 50000000 sys_clk]
    set_property CONFIG.FREQ_HZ 50000000 $c
    connect_bd_net $c [get_bd_pins core/sys_clk] [get_bd_pins ps7_0/M_AXI_GP0_ACLK] \
        [get_bd_pins axi/ACLK] [get_bd_pins axi/S00_ACLK] [get_bd_pins axi/M00_ACLK] \
        [get_bd_pins reset/slowest_sync_clk]
    set r [create_bd_port -dir I -type rst sys_rst_n]
    set_property CONFIG.POLARITY ACTIVE_LOW $r
    connect_bd_net $r [get_bd_pins reset/ext_reset_in]
    connect_bd_net [get_bd_pins reset/interconnect_aresetn] [get_bd_pins axi/ARESETN]
    connect_bd_net [get_bd_pins reset/peripheral_aresetn] [get_bd_pins axi/S00_ARESETN] \
        [get_bd_pins axi/M00_ARESETN] [get_bd_pins core/sys_rst_n]
    foreach name {shared_scl shared_sda mic_sd mic_sck mic_ws uart_txd led imu_scl imu_sda key_n ext_beep} {
        make_bd_pins_external [get_bd_pins core/$name]
        set_property NAME $name [get_bd_ports ${name}_0]
    }
    assign_bd_address -offset 0x40000000 -range 0x00040000 \
        -target_address_space [get_bd_addr_spaces ps7_0/Data] \
        [get_bd_addr_segs core/s_axi/reg0] -force
    validate_bd_design
    save_bd_design
    generate_target all [get_files s.bd]
    set wrappers [make_wrapper -files [get_files s.bd] -top]
    add_files $wrappers
    set_property top s_wrapper [get_filesets sources_1]
    set f [open $setup_marker w];puts $f "BD validated and generated";close $f
}
# Existing generated projects may reference the former inout-only I2C modules.
foreach f [get_files -quiet] {
    if {[file tail $f] in {i2c_startup_clear.v shared_i2c_bus.v i2c_transaction.v} &&
        [file dirname [file normalize $f]] ne [file join $stage rtl]} {remove_files $f}
}
foreach f [glob [file join $stage rtl *.v]] {if {[llength [get_files -quiet $f]]==0} {add_files $f}}
open_bd_design [get_files s.bd]
update_compile_order -fileset sources_1
update_module_reference [get_ips s_core_0]
save_bd_design
generate_target all [get_files s.bd]
update_compile_order -fileset sources_1
