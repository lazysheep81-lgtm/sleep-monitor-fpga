`timescale 1ns/1ps
module uart_tx #(parameter integer CLK_HZ=50_000_000, BAUD=115200)(
    input wire clk, input wire rst_n, input wire start, input wire [7:0] data,
    output reg tx, output reg busy
);
    localparam integer DIV=CLK_HZ/BAUD;
    reg [31:0] count;
    reg [3:0] bit_index;
    reg [9:0] bits;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin tx<=1; busy<=0; count<=0; bit_index<=0; bits<=10'h3ff; end
        else if (!busy) begin
            tx<=1;
            if (start) begin
                bits<={1'b1,data,1'b0}; tx<=0; busy<=1; count<=DIV-1; bit_index<=0;
            end
        end else if (count!=0) count<=count-1'b1;
        else if (bit_index==9) begin tx<=1; busy<=0; end
        else begin
            bit_index<=bit_index+1'b1; bits<={1'b1,bits[9:1]};
            tx<=bits[1]; count<=DIV-1;
        end
    end
endmodule

module uart_rx #(parameter integer CLK_HZ=50_000_000, BAUD=115200)(
    input wire clk, input wire rst_n, input wire rx,
    output reg [7:0] data, output reg valid
);
    localparam integer DIV=CLK_HZ/BAUD;
    (* ASYNC_REG="TRUE" *) reg [1:0] sync_rx;
    reg [1:0] state;
    reg [31:0] count;
    reg [2:0] bit_index;
    reg [7:0] shift;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) sync_rx<=2'b11;
        else sync_rx<={sync_rx[0],rx};
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin state<=0; count<=0; data<=0; valid<=0; bit_index<=0; shift<=0; end
        else begin
            valid<=0;
            case(state)
                0: if (!sync_rx[1]) begin state<=1; count<=DIV/2-1; end
                1: if (count!=0) count<=count-1'b1;
                   else if (!sync_rx[1]) begin state<=2; count<=DIV-1; bit_index<=0; end
                   else state<=0;
                2: if (count!=0) count<=count-1'b1;
                   else begin
                       shift[bit_index]<=sync_rx[1]; count<=DIV-1;
                       if (bit_index==7) state<=3;
                       else bit_index<=bit_index+1'b1;
                   end
                3: if (count!=0) count<=count-1'b1;
                   else begin
                       if (sync_rx[1]) begin data<=shift; valid<=1; end
                       state<=0;
                   end
            endcase
        end
    end
endmodule
